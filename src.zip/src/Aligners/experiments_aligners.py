import copy
import os
import pickle
import time

import numpy as np
import torch
import torch.optim as optim
from medclip import MedCLIPProcessor
from tqdm import tqdm

from Aligners.aligner_utils import get_aligner_ip_op_size, get_variance, get_pos_disease_data, \
    get_report_sentence_embeddings, group_patients
from Aligners.single_layer_network import Single_layer_network
from Plots.plots import create_barplot
from metrics import compute_AUC
from utils import get_device


def save_features(args, loader, device, mode):
    all_reps_classifier = []
    all_reps_clip = []
    out_put_GT = torch.FloatTensor().cuda()
    out_put_predict = torch.FloatTensor().cuda()
    out_put_tubes = torch.FloatTensor().cuda()
    out_put_tube_prob = torch.FloatTensor().cuda()

    processor = MedCLIPProcessor()
    print(f"First saving {mode} representations..")
    with torch.no_grad():
        with tqdm(total=len(loader)) as t:
            for batch_id, data in enumerate(loader):
                reps_classifier = None

                classifier_img = data["clf_img"].to(device)
                raw_img = data["raw_img"]
                text = data["text"]
                targets = data["lab"].to(device)
                tube_prob = data["tube_prob"].to(device)
                tube_label = data["tube_label"].to(device)

                inputs = processor(text=text, images=raw_img, return_tensors="pt", padding=True)
                outputs = args.med_clip(**inputs)
                reps_clip = [x.detach().cpu().numpy() for x in outputs["img_embeds"]]

                y_hat, raw_features, pooled_features = args.classifier(classifier_img)
                if args.flattening_type == "adaptive":
                    reps_classifier = [x.detach().cpu().numpy() for x in pooled_features]
                elif args.flattening_type == "flattened":
                    bs, channel_size, filter_1, filter_2 = raw_features.size(0), raw_features.size(
                        1), raw_features.size(2), raw_features.size(3)
                    raw_features = raw_features.view(bs, channel_size * filter_1 * filter_2)
                    reps_classifier = [x.detach().cpu().numpy() for x in raw_features]

                all_reps_classifier.extend(reps_classifier)
                all_reps_clip.extend(reps_clip)

                out_put_predict = torch.cat((out_put_predict, y_hat), dim=0)
                out_put_GT = torch.cat((out_put_GT, targets), dim=0)
                out_put_tubes = torch.cat((out_put_tubes, tube_label), dim=0)
                out_put_tube_prob = torch.cat((out_put_tube_prob, tube_prob), dim=0)

                t.set_postfix(epoch='{0}'.format(batch_id))
                t.update()

        all_reps_classifier = np.stack(all_reps_classifier)
        all_reps_clip = np.stack(all_reps_clip)

        print("All data: ")
        out_AUROC_all, out_AUPRC_all = compute_AUC(gt=out_put_GT, pred=out_put_predict)
        print(f"AuROC: {out_AUROC_all}, AuRPC: {out_AUPRC_all}")
        print(" ")

        print(
            f"Classifier {mode} embedding shape: {all_reps_classifier.shape}, "
            f"Med Clip {mode} embedding shape: {all_reps_clip.shape} "
        )
        np.save(
            args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.arch}_embeddings.npy",
            all_reps_classifier
        )

        if not os.path.exists(args.medclip_output_path):
            np.save(
                args.medclip_output_path / f"{mode}_{args.flattening_type}_medclip_vision_encoder_"
                                           f"{args.medclip_vision_encoder}_embeddings.npy",
                all_reps_clip
            )

        torch.save(out_put_GT.cpu(),
                   args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.arch}_GT.pth.tar")
        torch.save(out_put_predict.cpu(),
                   args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.arch}_predictions.pth.tar")
        torch.save(out_put_tubes.cpu(),
                   args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.arch}_tubes.pth.tar")
        torch.save(out_put_tube_prob.cpu(),
                   args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.arch}_tube_prob.pth.tar")

        print("Image embeddings are saved at:")
        print(args.classifier_output_path)
        print(args.medclip_output_path)


def get_important_sentences_for_mean_mistakes_per_group(
        tensor_dict, report_word_ge, med_clip, topKsentences, sent_save_path, find_sent_or_report="sent"
):
    print(
        "\n===================> Getting reports for mean positive correct and incorrect samples <==================="
    )
    test_medclip_img_emb_correct = tensor_dict["test_medclip_img_emb_correct"]
    test_medclip_img_emb_incorrect = tensor_dict["test_medclip_img_emb_incorrect"]
    report_sent_emb = None
    report_sent_dict = None
    save_file_name = None
    if find_sent_or_report == "sent":
        report_sent_emb = tensor_dict["report_sent_emb"]
        report_sent_dict = tensor_dict["report_sent_dict"]
        save_file_name = f"top_{topKsentences}_sentences_mean_mistakes_per_group_global.pkl"
    elif find_sent_or_report == "report":
        report_sent_emb = tensor_dict["report_emb"]
        report_sent_dict = tensor_dict["report_dict"]
        save_file_name = f"top_{topKsentences}_report_word_ge_{report_word_ge}_mean_mistakes_per_group_global.pkl"

    print(f"Correct size: {test_medclip_img_emb_correct.size()}")
    print(f"Incorrect size: {test_medclip_img_emb_incorrect.size()}")
    print(test_medclip_img_emb_incorrect.size())
    mean_img_emb_correct = torch.mean(test_medclip_img_emb_correct, dim=0)
    mean_img_emb_incorrect = torch.mean(test_medclip_img_emb_incorrect, dim=0)
    print(f"Mean correct size: {mean_img_emb_correct.size()}")
    print(f"Mean incorrect size: {mean_img_emb_incorrect.size()}")

    sent_sim_correct = torch.matmul(mean_img_emb_correct, report_sent_emb.t()) * med_clip.logit_scale.cpu()
    sent_sim_incorrect = torch.matmul(mean_img_emb_incorrect, report_sent_emb.t()) * med_clip.logit_scale.cpu()
    print(sent_sim_correct.size(), sent_sim_incorrect.size())

    sent_sim_correct_idx = torch.topk(sent_sim_correct, k=topKsentences, dim=0).indices.squeeze()
    sent_sim_incorrect_idx = torch.topk(sent_sim_incorrect, k=topKsentences, dim=0).indices.squeeze()

    sentences = list(report_sent_dict.keys())
    sent_correct = [sentences[i] for i in sent_sim_correct_idx]
    sent_incorrect = [sentences[i] for i in sent_sim_incorrect_idx]
    big_sentence_corr = ""
    big_sentence_incorr = ""
    for i, sentence in enumerate(sent_correct, start=1):
        big_sentence_corr += f"{i}. {sentence}\n"

    for i, sentence in enumerate(sent_incorrect, start=1):
        big_sentence_incorr += f"{i}. {sentence}\n"

    pickle.dump({
        "sent_correct": big_sentence_corr,
        "sent_incorrect": big_sentence_incorr
    }, open(sent_save_path / save_file_name, "wb")
    )
    print(f"All the results are saved at: {sent_save_path}")


def get_important_sentences_for_mean_mistakes_using_difference(
        tensor_dict, med_clip, topKsentences, sent_save_path, find_sent_or_report="sent"
):
    print("\n=======> Getting sentences using the mean difference b/w positive correct and incorrect samples <=======")
    test_medclip_img_emb_correct = tensor_dict["test_medclip_img_emb_correct"]
    test_medclip_img_emb_incorrect = tensor_dict["test_medclip_img_emb_incorrect"]
    report_sent_emb = None
    report_sent_dict = None
    save_file_name = None
    if find_sent_or_report == "sent":
        report_sent_emb = tensor_dict["report_sent_emb"]
        report_sent_dict = tensor_dict["report_sent_dict"]
        save_file_name = f"top_{topKsentences}_sentences_mean_mistakes_difference_group_global.pkl"
    elif find_sent_or_report == "report":
        report_sent_emb = tensor_dict["report_emb"]
        report_sent_dict = tensor_dict["report_dict"]
        save_file_name = f"top_{topKsentences}_report_mean_mistakes_difference_group_global.pkl"

    print(f"Correct size: {test_medclip_img_emb_correct.size()}")
    print(f"Incorrect size: {test_medclip_img_emb_incorrect.size()}")
    mean_img_emb_correct = torch.mean(test_medclip_img_emb_correct, dim=0)
    mean_img_emb_incorrect = torch.mean(test_medclip_img_emb_incorrect, dim=0)
    print(f"Mean correct size: {mean_img_emb_correct.size()}")
    print(f"Mean incorrect size: {mean_img_emb_incorrect.size()}")

    diff_embedding = torch.abs(mean_img_emb_correct - mean_img_emb_incorrect)
    print(f"Mean difference embedding size: {diff_embedding.size()}")

    sent_sim = torch.matmul(diff_embedding, report_sent_emb.t()) * med_clip.logit_scale.cpu()
    print(sent_sim.size())

    sent_sim_idx = torch.topk(sent_sim, k=topKsentences, dim=0).indices.squeeze()

    sentences = list(report_sent_dict.keys())
    sent = [sentences[i] for i in sent_sim_idx]
    big_sentence = ""
    for i, sentence in enumerate(sent, start=1):
        big_sentence += f"{i}. {sentence}\n"

    pickle.dump(big_sentence, open(sent_save_path / save_file_name, "wb"))
    print(f"All the results are saved at: {sent_save_path}")


def get_important_sentences_for_mistakes_using_difference_mean(
        tensor_dict, med_clip, topKsentences, sent_save_path, shortcut_label
):
    print("\n=======> Getting sentences using the mean difference b/w positive correct and incorrect samples <=======")
    test_medclip_img_emb_correct = tensor_dict["test_medclip_img_emb_correct"]
    test_medclip_img_emb_incorrect = tensor_dict["test_medclip_img_emb_incorrect"]
    report_sent_emb = tensor_dict["report_sent_emb"]
    report_sent_dict = tensor_dict["report_sent_dict"]

    print(f"Correct size: {test_medclip_img_emb_correct.size()}")
    print(f"Incorrect size: {test_medclip_img_emb_incorrect.size()}")
    sent_sim_tensor = torch.FloatTensor()

    start = time.time()
    for i in range(test_medclip_img_emb_incorrect.size(0)):
        patient_incorrect = test_medclip_img_emb_incorrect[i]
        diff_embedding = torch.abs(test_medclip_img_emb_correct - patient_incorrect)
        sent_sim = torch.matmul(report_sent_emb, diff_embedding.t()) * med_clip.logit_scale.cpu()
        sent_sim = torch.max(sent_sim, dim=1)[0]
        sent_sim = sent_sim.view(1, -1)
        sent_sim_tensor = torch.cat((sent_sim_tensor, sent_sim), dim=0)

    done = time.time()
    elapsed = done - start
    print("Time elapsed: " + str(elapsed) + " secs")

    sent_sim_tensor_mean = torch.mean(sent_sim_tensor, dim=0).view(1, -1)
    print(f"Patient-sentence similarity matrix size: {sent_sim_tensor_mean.size()}")
    most_sim_sent_idx = torch.topk(sent_sim_tensor_mean, k=topKsentences, dim=1).indices.squeeze()
    most_sim_sent_idx = most_sim_sent_idx.tolist()
    sentences = list(report_sent_dict.keys())
    result_sent = [sentences[i] for i in most_sim_sent_idx]
    pickle.dump(
        result_sent, open(sent_save_path / f"top_{topKsentences}_sentences_mistakes_difference_mean_global.pkl", "wb")
    )
    print(f"All the results are saved at: {sent_save_path}")


def get_important_sentences_for_mistakes_using_difference_per_sample(
        tensor_dict, med_clip, topKsentences, sent_save_path, shortcut_label, find_sent_or_report="sent"
):
    final_results = []
    print("\n====> Getting sentences using the difference b/w mean positive correct and each incorrect samples <====")
    test_shortcut_label_incorrect = tensor_dict["test_shortcut_label_incorrect"]
    test_medclip_img_emb_correct = tensor_dict["test_medclip_img_emb_correct"]
    test_medclip_img_emb_incorrect = tensor_dict["test_medclip_img_emb_incorrect"]
    report_sent_emb = None
    report_sent_dict = None
    save_file_name = None
    if find_sent_or_report == "sent":
        report_sent_emb = tensor_dict["report_sent_emb"]
        report_sent_dict = tensor_dict["report_sent_dict"]
        save_file_name = f"top_{topKsentences}_sentences_mistakes_difference_group_local.pkl"
    elif find_sent_or_report == "report":
        report_sent_emb = tensor_dict["report_emb"]
        report_sent_dict = tensor_dict["report_dict"]
        save_file_name = f"top_{topKsentences}_report_mistakes_difference_group_local.pkl"

    print(f"Correct size: {test_medclip_img_emb_correct.size()}")
    print(f"Incorrect size: {test_medclip_img_emb_incorrect.size()}")

    start = time.time()
    for i in range(test_medclip_img_emb_incorrect.size(0)):
        patient_incorrect = test_medclip_img_emb_incorrect[i]
        diff_embedding = torch.abs(test_medclip_img_emb_correct - patient_incorrect)
        sent_sim = torch.matmul(report_sent_emb, diff_embedding.t()) * med_clip.logit_scale.cpu()
        sent_sim = torch.max(sent_sim, dim=1)[0]
        sent_sim = sent_sim.view(1, -1)
        most_sim_sent_idx = torch.topk(sent_sim, k=topKsentences, dim=1).indices.squeeze()
        # print(f"Most similar sentence indices for each patient: {most_sim_sent_idx.size()}")
        most_sim_sent_idx = most_sim_sent_idx.tolist()
        sentences = list(report_sent_dict.keys())
        result_sent = [sentences[i] for i in most_sim_sent_idx]
        big_sentence = ""
        for sent_id, sentence in enumerate(result_sent, start=1):
            big_sentence += f"{sent_id}. {sentence}\n"
        count_with_tube = sum("tube" in sentence or "tubes" in sentence for sentence in result_sent)
        print(f"(incorrect - correct): "
              f"{count_with_tube}/{len(result_sent)} ({(count_with_tube / len(result_sent)) * 100} %)")

        print("<=============================================>")
        print(f"Incorrect patient: {i}, Most similar sentence indices for each patient: {len(most_sim_sent_idx)}")
        # print(result_sent)
        print("<=============================================>")

        patient_dict = {
            "patient_id": i,
            "tube": test_shortcut_label_incorrect[i].item(),
            "sentences": big_sentence,
            "count_with_tube": count_with_tube
        }
        final_results.append(patient_dict)

    done = time.time()
    elapsed = done - start
    print("Time elapsed: " + str(elapsed) + " secs")

    pickle.dump(final_results, open(sent_save_path / save_file_name, "wb"))

    count_w_tubes = 0
    tot_tube = 0
    for patient in final_results:
        if patient["count_with_tube"] >= 1:
            count_w_tubes += 1
            tot_tube += patient["count_with_tube"]

    print(f"{count_w_tubes}/{len(final_results)}")
    tot_sent = (len(final_results) * topKsentences)
    print(f"{tot_tube}/{tot_sent}")

    print(f"All the results are saved at: {sent_save_path}")


def get_important_concepts_for_mistakes_per_group(
        test_medclip_img_emb, concept_embedding_dict, med_clip, topKconcepts, prompt_keys, concept_save_path,
        group="correct", largest=True
):
    order = "top" if largest else "bottom"
    result_dict = {}
    for concept_prompt, concept_embeddings in concept_embedding_dict.items():
        result_dict[concept_prompt] = {}
        print("======" * 20)
        print(
            f"Calculating {order} {topKconcepts} concepts for concept prompt type {concept_prompt} for {group}ly "
            f"classified group"
        )
        concept_sim_clip_aligner_tensor = torch.FloatTensor()
        for i in range(test_medclip_img_emb.size(0)):
            patient = test_medclip_img_emb[i].view(1, -1)
            logits_per_text = torch.matmul(concept_embeddings.cpu(), patient.t()) * med_clip.logit_scale.cpu()
            logits_per_text = torch.max(logits_per_text, dim=1)[0]
            logits_per_text = logits_per_text.view(1, -1)
            concept_sim_clip_aligner_tensor = torch.cat(
                (concept_sim_clip_aligner_tensor, logits_per_text), dim=0
            )
        print(f"Patient-concept similarity matrix size: {concept_sim_clip_aligner_tensor.size()}")
        most_sim_concept_idx = torch.topk(
            concept_sim_clip_aligner_tensor, k=topKconcepts, dim=1, largest=largest
        ).indices.squeeze()

        most_sim_concept_idx = most_sim_concept_idx.tolist()
        # print(most_sim_concept_idx)
        concepts = list(prompt_keys[concept_prompt].keys())
        item_counts = {item: [] for item in concepts}

        # Count the occurrences for each item in each patient
        for patient in most_sim_concept_idx:
            for item in concepts:
                item_counts[item].append(patient.count(concepts.index(item)))

        total_patients = len(most_sim_concept_idx)
        result = {}
        for concept in concepts:
            result[concept] = item_counts[concept].count(1) / total_patients

        result_dict[concept_prompt] = result
        create_barplot(
            x_data=list(result.keys()),
            y_data=list(result.values()), fig_size=(12, 6),
            plt_title=f"Frequency of {order} {topKconcepts} concepts by {group}ly classified patients",
            color="#E24A33",
            x_label="Concepts", y_label="Frequencies", x_rotation=90, y_rotation=0,
            save_path=concept_save_path / f"plot_{order}_{topKconcepts}_"
                                          f"concepts_concept_prompt_{concept_prompt}_{group}ly_classified.png",
            dpi=500
        )
        print("======" * 20)

    pickle.dump(result_dict, open(concept_save_path / f"{order}_{topKconcepts}_concepts_{group}.pkl", "wb"))

    print(result_dict)
    print(f"All the results are saved at: {concept_save_path}")


def get_important_concepts_for_mistakes(
        tensor_dict, med_clip, topKconcepts, prompt_keys, concept_save_path, largest=True
):
    order = "top" if largest else "bottom"
    test_medclip_img_emb_correct = tensor_dict["test_medclip_img_emb_correct"]
    test_medclip_img_emb_incorrect = tensor_dict["test_medclip_img_emb_incorrect"]
    result_dict = {}
    for concept_prompt, concept_embeddings in tensor_dict["concept_embedding_dict"].items():
        result_dict[concept_prompt] = {}
        print("======" * 20)
        print(f"Calculating {order} {topKconcepts} concepts for concept prompt type {concept_prompt}")
        concept_sim_clip_aligner_tensor = torch.FloatTensor()
        for i in range(test_medclip_img_emb_incorrect.size(0)):
            patient_incorrect = test_medclip_img_emb_incorrect[i]
            diff_embedding = torch.abs(test_medclip_img_emb_correct - patient_incorrect)
            logits_per_text = torch.matmul(concept_embeddings.cpu(), diff_embedding.t()) * med_clip.logit_scale.cpu()
            logits_per_text = torch.max(logits_per_text, dim=1)[0]
            logits_per_text = logits_per_text.view(1, -1)
            concept_sim_clip_aligner_tensor = torch.cat(
                (concept_sim_clip_aligner_tensor, logits_per_text), dim=0
            )
        print(f"Patient-concept similarity matrix size: {concept_sim_clip_aligner_tensor.size()}")
        most_sim_concept_idx = torch.topk(
            concept_sim_clip_aligner_tensor, k=topKconcepts, dim=1, largest=largest
        ).indices.squeeze()
        most_sim_concept_idx = most_sim_concept_idx.tolist()
        # print(most_sim_concept_idx)
        concepts = list(prompt_keys[concept_prompt].keys())
        item_counts = {item: [] for item in concepts}

        # Count the occurrences for each item in each patient
        for patient in most_sim_concept_idx:
            for item in concepts:
                item_counts[item].append(patient.count(concepts.index(item)))

        total_patients = len(most_sim_concept_idx)
        result = {}
        for concept in concepts:
            result[concept] = item_counts[concept].count(1) / total_patients

        result_dict[concept_prompt] = result

        create_barplot(
            x_data=list(result.keys()),
            y_data=list(result.values()), fig_size=(12, 6),
            plt_title="Frequency of concepts for misclassified patients by taking the difference of image embeddings",
            color="#E24A33",
            x_label="Concepts", y_label="Frequencies", x_rotation=90, y_rotation=0,
            save_path=concept_save_path / f"plot_{order}_{topKconcepts}_concepts_prompt_{concept_prompt}_"
                                          f"using_difference.png",
            dpi=500
        )
        print("======" * 20)

    pickle.dump(result_dict, open(concept_save_path / f"{order}_{topKconcepts}_concepts_using_difference.pkl", "wb"))

    print(result_dict)
    print(f"All the results are saved at: {concept_save_path}")


def init(args):
    test_gt_disease, test_pred_disease, test_shortcut_label, test_clf_img_emb = get_pos_disease_data(
        args, mode="test", get_positive_only=True
    )
    aligner_dict = torch.load(args.aligner_path / args.aligner_name)
    W, b = [aligner_dict[x].float() for x in ['W', 'b']]
    W = W.float()
    b = b.float()
    test_medclip_img_emb = test_clf_img_emb @ W.T + b

    print("===================> Classifier outputs size for test data <===================")
    print(
        test_gt_disease.size(), test_pred_disease.size(), test_shortcut_label.size(), test_clf_img_emb.size(),
        test_medclip_img_emb.size()
    )
    print("===================> Classifier outputs size for test data <===================")

    (
        test_gt_disease_correct, test_pred_disease_correct, test_shortcut_label_correct,
        test_clf_img_emb_correct, test_medclip_img_emb_correct
    ) = group_patients(
        test_gt_disease, test_pred_disease, test_shortcut_label, test_clf_img_emb, test_medclip_img_emb,
        get_correct=True
    )
    print("===================> Train sizes for correctly classified samples: <===================")
    print(
        test_gt_disease_correct.size(), test_pred_disease_correct.size(), test_shortcut_label_correct.size(),
        test_clf_img_emb_correct.size(), test_medclip_img_emb_correct.size()
    )
    print("===================> Train sizes for correctly classified samples: <===================")

    (
        test_gt_disease_incorrect, test_pred_disease_incorrect, test_shortcut_label_incorrect,
        test_clf_img_emb_incorrect, test_medclip_img_emb_incorrect
    ) = group_patients(
        test_gt_disease, test_pred_disease, test_shortcut_label, test_clf_img_emb, test_medclip_img_emb,
        get_correct=False
    )
    print("===================> Train sizes for incorrectly classified samples: <===================")
    print(
        test_gt_disease_incorrect.size(), test_pred_disease_incorrect.size(), test_shortcut_label_incorrect.size(),
        test_clf_img_emb_incorrect.size(), test_medclip_img_emb_incorrect.size()
    )
    print("===================> Train sizes for inorrectly classified samples: <===================")

    report_sent_emb, report_sent_dict, report_emb, report_dict = get_report_sentence_embeddings(args)
    print(f"Report sentence embedding vector size: {report_sent_emb.size()}")
    print(f"Report sentence embedding dict size: {len(list(report_sent_dict.keys()))}")
    print(f"Report embedding vector size: {report_emb.size()}")
    print(f"Report embedding dict size: {len(list(report_dict.keys()))}")

    concept_embedding_dict = {}
    for concept_prompt_type in args.concept_prompt_type:
        concept_emb = pickle.load(open(
            args.medclip_output_path / f"concept_type_{concept_prompt_type}_vision_encoder_"
                                       f"{args.medclip_vision_encoder}_embeddings.pkl", "rb")
        )
        concept_emb = torch.stack(concept_emb).squeeze()
        print(f"Concept Embedding size for {concept_prompt_type}: {concept_emb.size()}")
        concept_embedding_dict[concept_prompt_type] = concept_emb

    return {
        "test_gt_disease_correct": test_gt_disease_correct,
        "test_pred_disease_correct": test_pred_disease_correct,
        "test_shortcut_label_correct": test_shortcut_label_correct,
        "test_clf_img_emb_correct": test_clf_img_emb_correct,
        "test_medclip_img_emb_correct": test_medclip_img_emb_correct,
        "test_gt_disease_incorrect": test_gt_disease_incorrect,
        "test_pred_disease_incorrect": test_pred_disease_incorrect,
        "test_shortcut_label_incorrect": test_shortcut_label_incorrect,
        "test_clf_img_emb_incorrect": test_clf_img_emb_incorrect,
        "test_medclip_img_emb_incorrect": test_medclip_img_emb_incorrect,
        "report_sent_emb": report_sent_emb,
        "report_sent_dict": report_sent_dict,
        "report_emb": report_emb,
        "report_dict": report_dict,
        "concept_embedding_dict": concept_embedding_dict
    }


def test_aligner(args):
    concept_save_path = args.aligner_path / f"medclip_vision_encoder_{args.medclip_vision_encoder}_top_concepts" / \
                        f"top_{args.topKconcepts}"
    sent_save_path = args.aligner_path / f"medclip_vision_encoder_{args.medclip_vision_encoder}_top_sentences" / \
                     f"top_{args.topKsentences}"
    os.makedirs(concept_save_path, exist_ok=True)
    os.makedirs(sent_save_path, exist_ok=True)

    tensor_dict = init(args)
    # get top reports
    get_important_sentences_for_mean_mistakes_per_group(
        tensor_dict, args.report_word_ge, args.med_clip, args.topKsentences, sent_save_path, find_sent_or_report="report"
    )

    # get the top sentences
    get_important_sentences_for_mean_mistakes_per_group(
        tensor_dict, args.report_word_ge, args.med_clip, args.topKsentences, sent_save_path, find_sent_or_report="sent"
    )
    get_important_sentences_for_mean_mistakes_using_difference(
        tensor_dict, args.med_clip, args.topKsentences, sent_save_path
    )
    get_important_sentences_for_mistakes_using_difference_per_sample(
        tensor_dict, args.med_clip, args.topKsentences, sent_save_path, shortcut_label=args.shortcut
    )

    get_important_concepts_for_mistakes(
        tensor_dict, args.med_clip, args.topKconcepts, args.prompt_keys, concept_save_path
    )

    # get top concepts for correctly classified samples
    get_important_concepts_for_mistakes_per_group(
        tensor_dict["test_medclip_img_emb_correct"], tensor_dict["concept_embedding_dict"],
        args.med_clip, args.topKconcepts, args.prompt_keys, concept_save_path,
        group="correct", largest=True
    )

    # get bottom concepts for correctly classified samples
    get_important_concepts_for_mistakes_per_group(
        tensor_dict["test_medclip_img_emb_correct"], tensor_dict["concept_embedding_dict"],
        args.med_clip, args.topKconcepts, args.prompt_keys, concept_save_path,
        group="correct", largest=False
    )

    # get top concepts for incorrectly classified samples
    get_important_concepts_for_mistakes_per_group(
        tensor_dict["test_medclip_img_emb_incorrect"], tensor_dict["concept_embedding_dict"],
        args.med_clip, args.topKconcepts, args.prompt_keys, concept_save_path,
        group="incorrect", largest=True
    )

    # get bottom concepts for incorrectly classified samples
    get_important_concepts_for_mistakes_per_group(
        tensor_dict["test_medclip_img_emb_incorrect"], tensor_dict["concept_embedding_dict"],
        args.med_clip, args.topKconcepts, args.prompt_keys, concept_save_path,
        group="incorrect", largest=False
    )


    # get_important_sentences_for_mistakes_using_difference_mean(
    #     tensor_dict, args.med_clip, args.topKsentences, sent_save_path, args.shortcut
    # )


def train_aligner(args, train_loader, test_loader):
    device = get_device(args)
    args.classifier.to(device)
    args.classifier.eval()
    args.med_clip.to(device)
    args.med_clip.eval()

    print("Obtaining the representations for the classifier and medClip: ")
    if args.save_img_embeddings == "y" and args.dataset.lower() == "nih":
        save_features(args, train_loader, device, mode="train")
        save_features(args, test_loader, device, mode="test")

    print("=================>>>>>> Read representations <<<<<=================")
    print(
        args.classifier_output_path / f"train_{args.flattening_type}_classifier_{args.arch}_embeddings.npy"
    )
    print(
        args.classifier_output_path / f"test_{args.flattening_type}_classifier_{args.arch}_embeddings.npy"
    )
    print(
        args.medclip_output_path /
        f"train_{args.flattening_type}_medclip_vision_encoder_{args.medclip_vision_encoder}_embeddings.npy"
    )
    print(
        args.medclip_output_path /
        f"test_{args.flattening_type}_medclip_vision_encoder_{args.medclip_vision_encoder}_embeddings.npy"
    )
    print("===============================================================")

    train_reps_classifier = np.load(
        args.classifier_output_path / f"train_{args.flattening_type}_classifier_{args.arch}_embeddings.npy")
    test_reps_classifier = np.load(
        args.classifier_output_path / f"test_{args.flattening_type}_classifier_{args.arch}_embeddings.npy")
    train_reps_medclip = np.load(
        args.medclip_output_path / f"train_{args.flattening_type}_medclip_vision_encoder_{args.medclip_vision_encoder}_embeddings.npy"
    )
    test_reps_medclip = np.load(
        args.medclip_output_path / f"test_{args.flattening_type}_medclip_vision_encoder_{args.medclip_vision_encoder}_embeddings.npy"
    )

    print(
        f"Classifier train embedding shape: {train_reps_classifier.shape}, "
        f"Med Clip train embedding shape: {train_reps_medclip.shape} "
    )
    print(
        f"Classifier test embedding shape: {test_reps_classifier.shape}, "
        f"Med Clip test embedding shape: {test_reps_medclip.shape} "
    )
    print(f'Training linear aligner ...')
    print(f'Linear alignment: ({train_reps_classifier.shape}) --> ({train_reps_medclip.shape}).')

    var_train_reps_classifier = get_variance(train_reps_classifier)
    var_train_reps_medclip = get_variance(train_reps_medclip)
    var_test_reps_classifier = get_variance(test_reps_classifier)
    var_test_reps_medclip = get_variance(test_reps_medclip)

    c_train_classifier = (args.target_variance / var_train_reps_classifier) ** 0.5
    c_train_medclip = (args.target_variance / var_train_reps_medclip) ** 0.5
    c_test_classifier = (args.target_variance / var_test_reps_classifier) ** 0.5
    c_test_medclip = (args.target_variance / var_test_reps_medclip) ** 0.5

    train_reps_classifier = c_train_classifier * train_reps_classifier
    train_reps_medclip = c_train_medclip * train_reps_medclip
    test_reps_classifier = c_test_classifier * test_reps_classifier
    test_reps_medclip = c_test_medclip * test_reps_medclip

    criterion = torch.nn.MSELoss()
    aligner_dims = get_aligner_ip_op_size(args)
    aligner = Single_layer_network(aligner_dims["aligner_input_size"], aligner_dims["aligner_out_size"], bias=True)
    aligner.to(device)

    optimizer = optim.SGD(aligner.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

    W, b = do_train(
        train_reps_classifier, train_reps_medclip, test_reps_classifier, test_reps_medclip,
        aligner, optimizer, scheduler, criterion, args.num_epochs_aligner, device
    )

    W = W * c_train_classifier / c_train_medclip
    b = b * c_train_classifier / c_train_medclip

    aligner_name = f"{args.flattening_type}_aligner_classifier_{args.arch}_medclip_vision_encoder_{args.medclip_vision_encoder}_epochs_{args.num_epochs_aligner}.pth"
    torch.save({'b': b.detach().cpu(), 'W': W.detach().cpu()}, args.aligner_output_path / aligner_name)
    print(f"Aligner saved at:")
    print(args.aligner_output_path / aligner_name)


def do_train(
        train_reps_classifier, train_reps_medclip, test_reps_classifier, test_reps_medclip,
        aligner, optimizer, scheduler, criterion, epochs, device
):
    train_X = torch.from_numpy(train_reps_classifier).float()
    train_y = torch.from_numpy(train_reps_medclip).float()
    train_dataset = torch.utils.data.TensorDataset(train_X, train_y)
    train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=100, shuffle=True, num_workers=1)

    init_mse, init_r2 = do_test(test_reps_classifier, test_reps_medclip, aligner, criterion, device)
    print(f'Initial MSE, R^2: {init_mse:.3f}, {init_r2:.3f}')
    aligner.train()

    best_mse = 99999999
    best_W = 0
    best_b = 0
    for epoch in range(epochs):
        e_loss, num_of_batches = 0, 0

        for batch_idx, (reps_classifier, reps_med_clip) in enumerate(train_dataloader):
            num_of_batches += 1
            reps_classifier, reps_med_clip = reps_classifier.to(device), reps_med_clip.to(device)

            optimizer.zero_grad()
            reps_med_clip_hat = aligner(reps_classifier)

            loss = criterion(reps_med_clip_hat, reps_med_clip)
            e_loss += loss.item()

            loss.backward()
            optimizer.step()

        e_loss /= num_of_batches

        epoch_test_mse, epoch_test_r2 = do_test(test_reps_classifier, test_reps_medclip, aligner, criterion, device)

        if epoch_test_mse < best_mse:
            best_mse = epoch_test_mse
            for name, param in aligner.named_parameters():
                if name == 'linear.weight':
                    best_W = copy.deepcopy(param.detach())
                else:
                    best_b = copy.deepcopy(param.detach())

            print(f" best W: {best_W[0][0:10]}, best b: {best_b[0:10]}")
        print(
            f'Epoch number, {epoch}, loss: {e_loss:.3f}, '
            f'test MSE: {epoch_test_mse:.3f}, test_r2: {epoch_test_r2:.3f}, '
            f'best MSE: {best_mse:.3f}'
        )

        scheduler.step()

    final_mse, final_r2 = do_test(test_reps_classifier, test_reps_medclip, aligner, criterion, device)
    print(f'Final MSE, R^2: {final_mse:.3f}, {final_r2:.3f}')

    for name, param in aligner.named_parameters():
        if name == 'linear.weight':
            W = param.detach()
        else:
            b = param.detach()

    print(f"final W: {W[0][0:10]}, best W: {best_W[0][0:10]}, final b: {b[0:10]}, best b: {best_b[0:10]}")

    return best_W, best_b


def do_test(X, Y, aligner, criterion, device):
    tensor_X = torch.from_numpy(X).float()
    tensor_Y = torch.from_numpy(Y).float()
    dataset = torch.utils.data.TensorDataset(tensor_X, tensor_Y)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=100, shuffle=False, num_workers=1)

    aligner.eval()
    total_mse_err, num_of_batches = 0, 0

    with torch.no_grad():
        for batch_idx, (reps_classifier, reps_med_clip) in enumerate(dataloader):
            num_of_batches += 1
            reps_classifier, reps_med_clip = reps_classifier.to(device), reps_med_clip.to(device)

            reps_med_clip_hat = aligner(reps_classifier)
            loss = criterion(reps_med_clip_hat, reps_med_clip)

            total_mse_err += loss.item()

    total_mse_err /= num_of_batches

    return total_mse_err, 1 - total_mse_err / get_variance(Y)
