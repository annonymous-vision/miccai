import pickle

import numpy as np
import torch


def get_aligner_ip_op_size(args):
    aligner_out_size = 512
    aligner_input_size = 0
    if args.arch.lower() == "densenet121" and args.flattening_type == "adaptive":
        aligner_input_size = 1024
    elif args.arch.lower() == "densenet121" and args.flattening_type == "flattened":
        aligner_input_size = 1024 * 7 * 7
    if args.arch.lower() == "resnet50" and args.flattening_type == "adaptive":
        aligner_input_size = 2048
    elif args.arch.lower() == "resnet50" and args.flattening_type == "flattened":
        aligner_input_size = 2048 * 7 * 7

    return {
        "aligner_out_size": aligner_out_size,
        "aligner_input_size": aligner_input_size
    }


def get_variance(y: np.ndarray):
    ey = np.mean(y)
    ey2 = np.mean(np.square(y))
    return ey2 - ey ** 2


def get_pos_disease_data(args, mode="train", get_positive_only=True):
    gt_disease = torch.load(
        args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.classifier}_GT.pth.tar"

    ).squeeze()
    pred_disease = (torch.sigmoid(
        torch.load(
            args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.classifier}_predictions.pth.tar"
        )
    ) > 0.5).int().squeeze()

    shortcut_label = torch.load(
        args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.classifier}_{args.shortcut}.pth.tar"
    ).squeeze()
    clf_img_emb = torch.from_numpy(
        np.load(
            args.classifier_output_path / f"{mode}_{args.flattening_type}_classifier_{args.classifier}_embeddings.npy")
    )

    if get_positive_only:
        pos_pt_idx = torch.nonzero(gt_disease == 1, as_tuple=True)[0]
        gt_disease = gt_disease[pos_pt_idx]
        pred_disease = pred_disease[pos_pt_idx]
        shortcut_label = shortcut_label[pos_pt_idx]
        clf_img_emb = clf_img_emb[pos_pt_idx]

    return gt_disease, pred_disease, shortcut_label, clf_img_emb


def group_patients(gt_disease, pred_disease, shortcut_label, clf_embeddings, medclip_img_emb, get_correct=True):
    gt_disease_idx = torch.nonzero(torch.eq(gt_disease, pred_disease), as_tuple=True)[0] if get_correct else \
        torch.nonzero(torch.ne(gt_disease, pred_disease), as_tuple=True)[0]

    gt_disease_set = gt_disease[gt_disease_idx]
    pred_disease_set = pred_disease[gt_disease_idx]
    shortcut_label_set = shortcut_label[gt_disease_idx]
    clf_embeddings_set = clf_embeddings[gt_disease_idx]
    medclip_img_emb_set = medclip_img_emb[gt_disease_idx]
    return gt_disease_set, pred_disease_set, shortcut_label_set, clf_embeddings_set, medclip_img_emb_set


def get_report_sentence_embeddings(args):
    report_sent_emb = torch.load(
        args.medclip_output_path / f"Complete_sentence_emb_{args.medclip_vision_encoder}.pth.tar")
    report_sent_dict = pickle.load(
        open(args.medclip_output_path / f"sentences_{args.medclip_vision_encoder}_dict.pkl", "rb"))
    report_emb = torch.load(
        args.medclip_output_path / f"Complete_report_emb_{args.medclip_vision_encoder}_word_ge_{args.report_word_ge}.pth.tar")
    report_dict = pickle.load(
        open(
            args.medclip_output_path / f"report_sentences_{args.medclip_vision_encoder}_dict_word_ge_{args.report_word_ge}.pkl",
            "rb"
        )
    )

    return report_sent_emb, report_sent_dict, report_emb, report_dict
