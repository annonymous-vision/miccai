import torch


class Single_layer_network(torch.nn.Module):
    def __init__(self, input_size, output_size, bias=True):
        super(Single_layer_network, self).__init__()
        self.linear = torch.nn.Linear(input_size, output_size, bias=bias)

    def forward(self, x):
        out = self.linear(x)
        return out
