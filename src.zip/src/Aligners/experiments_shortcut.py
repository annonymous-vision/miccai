import warnings

import numpy as np
import torch
from torch.utils.data import DataLoader

import utils
from Aligners.single_layer_network import Single_layer_network
from Datasets.feature_label_dataset import Feature_label_dataset
from metrics import compute_accuracy, compute_AUC

warnings.filterwarnings("ignore")


def get_classifier_outputs(args):
    train_shortcut = torch.load(
        args.classifier_output_path / f"train_adaptive_classifier_{args.classifier}_{args.shortcut}.pth.tar"
    )
    test_shortcut = torch.load(
        args.classifier_output_path / f"test_adaptive_classifier_{args.classifier}_{args.shortcut}.pth.tar"
    )

    train_gt = torch.load(args.classifier_output_path / f"train_adaptive_classifier_{args.classifier}_GT.pth.tar")
    test_gt = torch.load(args.classifier_output_path / f"test_adaptive_classifier_{args.classifier}_GT.pth.tar")

    train_clf_embeddings = torch.from_numpy(
        np.load(args.classifier_output_path / f"train_adaptive_classifier_{args.classifier}_embeddings.npy"))
    test_clf_embeddings = torch.from_numpy(
        np.load(args.classifier_output_path / f"test_adaptive_classifier_{args.classifier}_embeddings.npy"))

    train_clip_embeddings = torch.from_numpy(
        np.load(args.medclip_output_path / f"train_adaptive_medclip_vision_encoder_"
                                           f"{args.medclip_vision_encoder}_embeddings.npy")
    )
    test_clip_embeddings = torch.from_numpy(
        np.load(args.medclip_output_path / f"test_adaptive_medclip_vision_encoder_"
                                           f"{args.medclip_vision_encoder}_embeddings.npy")
    )

    print("===================> Classifier outputs size <===================")
    print(train_shortcut.size(), train_clf_embeddings.size(), train_clip_embeddings.size(), train_gt.size())
    print(test_shortcut.size(), test_clf_embeddings.size(), test_clip_embeddings.size(), test_gt.size())
    print("===================> Classifier outputs size <===================")

    return (
        train_shortcut, test_shortcut, train_gt, test_gt, train_clf_embeddings, test_clf_embeddings,
        train_clip_embeddings, test_clip_embeddings
    )


def get_dataloaders(
        train_shortcut, test_shortcut, train_gt, test_gt, train_embeddings, test_embeddings, apply_pos=True
):
    if apply_pos:
        train_shortcut_pos_pt_idx = torch.nonzero(train_gt == 1, as_tuple=True)[0]
        train_shortcut_pos_pt = train_shortcut[train_shortcut_pos_pt_idx]
        train_embeddings_pos_pt = train_embeddings[train_shortcut_pos_pt_idx]

        test_shortcut_pos_pt_idx = torch.nonzero(test_gt == 1, as_tuple=True)[0]
        test_shortcut_pos_pt = test_shortcut[test_shortcut_pos_pt_idx]
        test_embeddings_pos_pt = test_embeddings[test_shortcut_pos_pt_idx]
    else:
        train_shortcut_pos_pt = train_shortcut
        train_embeddings_pos_pt = train_embeddings
        test_shortcut_pos_pt = test_shortcut
        test_embeddings_pos_pt = test_embeddings

    print("===================> Positive outputs size <===================")
    # print(train_embeddings_pos_pt[0][0:10])
    # print(test_embeddings_pos_pt[0][0:10])
    print(train_shortcut_pos_pt.size(), train_embeddings_pos_pt.size())
    print(test_shortcut_pos_pt.size(), test_embeddings_pos_pt.size())
    print("===================> Positive outputs size <===================")

    train_tube_dataset = Feature_label_dataset(train_embeddings_pos_pt, train_shortcut_pos_pt)
    test_tube_dataset = Feature_label_dataset(test_embeddings_pos_pt, test_shortcut_pos_pt)

    train_dataloader = DataLoader(
        train_tube_dataset, batch_size=64, shuffle=True, num_workers=4, pin_memory=True
    )
    test_dataloader = DataLoader(
        test_tube_dataset, batch_size=64, shuffle=False, num_workers=4, pin_memory=True
    )

    return train_dataloader, test_dataloader


def do_classify(model, num_epochs, train_dataloader, test_dataloader, lr, device):
    criterion = torch.nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    best_acc = 0
    best_auroc = 0
    for epoch in range(num_epochs):
        total_train_loss, train_batch_id = 0, 0
        model.train()
        for data in train_dataloader:
            train_batch_id += 1
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device).unsqueeze(1)

            optimizer.zero_grad()
            outputs = model(inputs)
            train_loss = criterion(outputs, labels)
            train_loss.backward()
            optimizer.step()

            total_train_loss += train_loss.item()

        total_train_loss /= train_batch_id
        model.eval()
        total_val_loss, val_batch_id = 0, 0
        out_put_pred = torch.FloatTensor().cuda()
        out_put_gt = torch.FloatTensor().cuda()

        with torch.no_grad():
            for data in test_dataloader:
                val_batch_id += 1
                inputs, labels = data
                inputs = inputs.to(device)
                labels = labels.to(device).unsqueeze(1)

                outputs = model(inputs)
                val_loss = criterion(outputs, labels)
                total_val_loss += val_loss.item()

                task_output = torch.sigmoid(outputs)
                out_put_pred = torch.cat((out_put_pred, task_output), dim=0)
                out_put_gt = torch.cat((out_put_gt, labels), dim=0)

        total_val_loss /= val_batch_id
        tube_pred_pos_clf = (out_put_pred > 0.5).int()
        tube_gt_pos_clf = out_put_gt

        acc = compute_accuracy(gt=tube_gt_pos_clf, pred=tube_pred_pos_clf)
        auroc = compute_AUC(gt=tube_gt_pos_clf, pred=out_put_pred)[0]
        if auroc > best_auroc:
            best_auroc = auroc
            print(tube_gt_pos_clf.squeeze())
            print(tube_pred_pos_clf.squeeze())
            print(out_put_pred.squeeze())

        print(
            f'Epoch number, {epoch}, train_loss: {total_train_loss:.3f}, '
            f'val_loss: {total_val_loss:.3f}, acc: {acc:.3f}, auroc: {auroc:.3f}, best_auroc: {best_auroc:.3f}'
        )



def do_experiments(args):
    device = utils.get_device(args)

    (
        train_shortcut, test_shortcut, train_gt, test_gt, train_clf_embeddings,
        test_clf_embeddings, train_clip_embeddings, test_clip_embeddings
    ) = get_classifier_outputs(args)

    train_clf_dataloader, test_clf_dataloader = get_dataloaders(
        train_shortcut, test_shortcut, train_gt, test_gt, train_clf_embeddings,
        test_clf_embeddings, apply_pos=args.apply_pos
    )
    model_w_classifier_emb = Single_layer_network(input_size=train_clf_embeddings.size(1), output_size=1).to(device)
    print("\n===================> Training tube classifier with classifier embeddings: <===================\n")
    do_classify(
        model_w_classifier_emb, args.epochs, train_clf_dataloader, test_clf_dataloader, args.lr, device
    )
    print("===================> Training tube classifier with classifier embeddings: <===================")

    aligner_dict = torch.load(args.aligner_path / args.aligner_name)
    W, b = [aligner_dict[x].float() for x in ['W', 'b']]
    W = W.float()
    b = b.float()

    train_aligner_embeddings = train_clf_embeddings @ W.T + b
    test_aligner_embeddings = test_clf_embeddings @ W.T + b
    print("\n===================> Aligned embeddings size: <===================\n")
    print(train_aligner_embeddings.size(), test_aligner_embeddings.size())
    print("\n===================> Aligned embeddings size: <===================\n")

    train_aligner_dataloader, test_aligner_dataloader = get_dataloaders(
        train_shortcut, test_shortcut, train_gt, test_gt, train_aligner_embeddings, test_aligner_embeddings,
        apply_pos=args.apply_pos
    )
    model_w_aligner_emb = Single_layer_network(input_size=train_aligner_embeddings.size(1), output_size=1).to(device)
    print("\n===================> Training tube classifier with aligned MedClip embeddings: <===================\n")
    do_classify(model_w_aligner_emb, args.epochs, train_aligner_dataloader, test_aligner_dataloader, args.lr, device)
    print("\n===================> Training tube classifier with aligned MedClip embeddings: <===================\n")

    train_clip_dataloader, test_clip_dataloader = get_dataloaders(
        train_shortcut, test_shortcut, train_gt, test_gt, train_clip_embeddings, test_clip_embeddings,
        apply_pos=args.apply_pos
    )
    model_w_medclip_emb = Single_layer_network(input_size=train_clip_embeddings.size(1), output_size=1).to(device)
    print("\n===================> Training tube classifier with true MedClip embeddings: <===================\n")
    do_classify(model_w_medclip_emb, args.epochs, train_clip_dataloader, test_clip_dataloader, args.lr, device)
    print("\n===================> Training tube classifier with true MedClip embeddings: <===================\n")
