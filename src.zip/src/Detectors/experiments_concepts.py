import collections
import cv2
import gc
import os
import pandas as pd
import pickle
import random
import time
import torch
import warnings
from PIL import Image
from imgaug.augmentables.bbs import BoundingBox, BoundingBoxesOnImage
from pathlib import Path
from torch.optim import Adam
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from Datasets.dataset_concepts import MammoDataset_concept_detection, collator_mammo_datasett
from Datasets.dataset_utils import get_dataset, get_transforms
from Detectors.detectors_utils import _get_detections, _get_annotations, compute_overlap, _compute_ap
from Detectors.retinanet.detector_model import RetinaNet_efficientnet
from Detectors.retinanet.resnet_detector import resnet18, resnet34, resnet50, resnet101, resnet152
from Plots.plots import plot_concept_detector_results
from metrics import pfbeta_binarized, pr_auc, auroc, compute_accuracy, compute_auprc
from utils import seed_all, timeSince

warnings.filterwarnings("ignore")
import numpy as np


def do_experiements(args, device):
    args.data_dir = Path(args.data_dir)
    args.df = pd.read_csv(args.data_dir / args.csv_file)
    print(args.data_dir / args.csv_file)
    args.df = args.df.fillna(0)
    print(f"df shape: {args.df.shape}")

    if args.dataset.lower() == 'vindr' and args.inference_mode == 'n' and args.select_cancer == 'y':
        args.df = args.df.head(2254)
    args.model_base_name = args.arch
    seed_all(args.seed)
    args.cur_fold = 0

    if args.target_dataset.lower() == 'rsna':
        args.valid_folds = args.df
        print(f'valid: {args.valid_folds.shape}')
    elif args.dataset.lower() == 'vindr' or args.target_dataset.lower() == 'vindr':
        args.train_folds = args.df[args.df['split'] == "training"].reset_index(drop=True)
        args.valid_folds = args.df[args.df['split'] == "test"].reset_index(drop=True)
        print(f'train: {args.train_folds.shape}', f'valid: {args.valid_folds.shape}')

    print(args.valid_folds.columns)
    if args.running_interactive:
        # test on small subsets of data on interactive mode
        args.train_folds = args.train_folds.head(100)
        args.valid_folds = args.valid_folds.head(n=1000)
        # print(args.valid_folds[args.valid_folds["Architectural_Distortion"] == 1].shape)

    # if args.target_dataset.lower() == 'rsna' and args.inference_mode == 'y':
    #     inference_rsna(args, device)

    if args.inference_mode == 'y':
        inference_loop(args, device)
    elif args.inference_mode == 'n':
        train_loop(args, device)

    print(f'Checkpoints saved at: {args.chk_pt_path}')
    print(f'Outputs saved at: {args.output_path}')


def inference_rsna(args, device):
    print(f'\n================== fold: {args.cur_fold} inference ======================')
    transform, _, test_affine_trans = get_transforms(args)

    # Create the model
    if args.arch == 'resnet_18':
        retinanet = resnet18(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_34':
        retinanet = resnet34(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_50':
        retinanet = resnet50(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_101':
        retinanet = resnet101(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_152':
        retinanet = resnet152(num_classes=len(args.concepts), pretrained=True)
    else:
        retinanet = RetinaNet_efficientnet(
            num_classes=len(args.concepts), model_type=args.arch, focal_alpha=args.focal_alpha,
            focal_gamma=args.focal_gamma
        )

    retinanet.to(device)
    chk_pt = torch.load(
        args.chk_pt_path / f'{args.arch}_seed_{args.seed}_fold_{args.cur_fold}_best_auroc.pth',
        map_location=device
    )
    retinanet.load_state_dict(chk_pt['state_dict'])
    retinanet.eval()

    valid_dataset = MammoDataset_concept_detection(
        args=args, df=args.valid_folds, iaa_transform=test_affine_trans, transform=transform
    )
    valid_loader = DataLoader(
        valid_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True,
        drop_last=False, collate_fn=collator_mammo_datasett
    )
    print(f'valid_loader: {len(valid_loader)}', f'valid_dataset: {len(valid_dataset)}')

    pred_proba = []
    if len(args.concepts) == 1:
        concept = args.concepts[0]
    else:
        concept = args.concepts[1]

    if concept.lower() == 'suspicious calcification':
        concept = "Suspicious_Calcification"
    elif concept.lower() == 'suspicious lymph node':
        concept = "Suspicious_Lymph_Node"
    elif concept.lower() == 'skin retraction':
        concept = "Skin_Retraction"
    elif concept.lower() == 'global asymmetry':
        concept = "Global_Asymmetry"
    elif concept.lower() == 'skin thickening':
        concept = "Skin_Thickening"

    with tqdm(total=len(valid_loader)) as t:
        for step, batch in enumerate(valid_loader):
            x = batch['x'].to(device)

            with torch.no_grad():
                scores, _, _ = retinanet(x)

            proba = 0
            is_empty = torch.numel(scores) == 0
            if not is_empty:
                max_score_index = torch.argmax(scores)
                if scores[max_score_index] > args.score_threshold:
                    proba = scores[max_score_index].item()
                else:
                    proba = scores[max_score_index].item()

            pred_proba.append(proba)
            t.update()

    binary_values = [1 if prob > args.score_threshold else 0 for prob in pred_proba]
    args.valid_folds[f'Proba_{concept}_th_{args.score_threshold}'] = pred_proba
    args.valid_folds[f'{concept}_th_{args.score_threshold}'] = binary_values
    print(args.valid_folds)
    print(args.valid_folds.columns)
    args.valid_folds.to_csv(
        args.data_dir / 'RSNA_Cancer_Detection' / f'train_folds_{concept}_v1_th_{args.score_threshold}.csv', index=False
    )
    print(args.data_dir / 'RSNA_Cancer_Detection' / f'train_folds_{concept}_v1_th_{args.score_threshold}.csv')


def inference_loop(args, device):
    print(f'\n================== fold: {args.cur_fold} inference ======================')
    transform, _, test_affine_trans = get_transforms(args)

    # Create the model
    if args.arch == 'resnet_18':
        retinanet = resnet18(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_34':
        retinanet = resnet34(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_50':
        retinanet = resnet50(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_101':
        retinanet = resnet101(num_classes=len(args.concepts), pretrained=True)
    elif args.arch == 'resnet_152':
        retinanet = resnet152(num_classes=len(args.concepts), pretrained=True)
    else:
        retinanet = RetinaNet_efficientnet(
            num_classes=len(args.concepts), model_type=args.arch, focal_alpha=args.focal_alpha,
            focal_gamma=args.focal_gamma
        )

    retinanet.to(device)
    chk_pt = torch.load(
        args.chk_pt_path / f'{args.arch}_seed_{args.seed}_fold_{args.cur_fold}_best_auroc.pth',
        map_location=device
    )
    retinanet.load_state_dict(chk_pt['state_dict'])
    retinanet.eval()
    print('model loaded')

    target_labels = []
    pred_proba = []
    random_image_ids = []
    th = args.score_threshold
    concept = None
    if len(args.concepts) == 1:
        concept = args.concepts[0]
    else:
        concept = args.concepts[1]

    args.image_path = args.output_path / args.target_dataset / concept
    os.makedirs(args.image_path, exist_ok=True)

    if concept.lower() == 'suspicious calcification':
        concept = "Suspicious_Calcification"
    elif concept.lower() == 'suspicious lymph node':
        concept = "Suspicious_Lymph_Node"
    elif concept.lower() == 'skin retraction':
        concept = "Skin_Retraction"
    elif concept.lower() == 'global asymmetry':
        concept = "Global_Asymmetry"
    elif concept.lower() == 'skin thickening':
        concept = "Skin_Thickening"

    _dict = {}
    args.valid_folds = args.valid_folds[args.valid_folds["cancer"] == 1]
    with tqdm(total=len(list(args.valid_folds.iterrows()))) as t:
        for index, row in args.valid_folds.iterrows():
            if args.target_dataset.lower() == 'vindr':
                target_label = row[concept]
                breast_birads = row["breast_birads"]
                study_id = row["study_id"]
                image_id = row["image_id"]
                image_name = args.image_path / f'{concept}_{target_label}_{breast_birads}_{study_id}_{image_id}.png'
            elif args.target_dataset.lower() == 'rsna':
                target_label = 0
                breast_birads = row["BIRADS"]
                study_id = str(row["patient_id"])
                image_id = str(row["image_id"])
                random_number = random.random()
                _dict[f"cancer_{row['cancer']}_BIRADS_{breast_birads}_{study_id}_{image_id}"] = random_number
                random_image_ids.append(random_number)
                image_name = args.image_path / f"{str(random_number)}.png"
                # image_name = args.image_path / f"cancer_{row['cancer']}_BIRADS_{breast_birads}_{study_id}_{image_id}.png"

            img_path = f"{args.data_dir / args.img_dir / study_id / image_id}"
            image_orig = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            image = Image.fromarray(image_orig).convert('RGB')
            image = np.array(image)

            if target_label == 0:
                bb_truth = [0, 0, 0, 0]
                bb_orig = [0, 0, 0, 0]
            else:
                bb_truth = row[["resized_xmin", "resized_ymin", "resized_xmax", "resized_ymax"]].values.tolist()
                bb_orig = bb_truth.copy()

            bb_box = [BoundingBox(x1=bb_truth[0], y1=bb_truth[1], x2=bb_truth[2], y2=bb_truth[3])]
            bbs_on_image = BoundingBoxesOnImage(bb_box, shape=image.shape)

            image_to_save, bb_truth = test_affine_trans(
                image=image,
                bounding_boxes=[bbs_on_image]
            )
            bb_gt = []
            for idx, bb in enumerate(bb_truth[0]):
                bb_gt.append([bb.x1, bb.y1, bb.x2, bb.y2])

            image_tensor = transform(image_to_save)
            image_tensor = image_tensor.to(torch.float32)
            image_tensor -= image_tensor.min()
            image_tensor /= image_tensor.max()
            image_tensor = torch.tensor((image_tensor - args.mean) / args.std, dtype=torch.float32).to(device)

            with torch.no_grad():
                scores, classification, transformed_anchors = retinanet(image_tensor.unsqueeze(dim=0))

            proba = 0
            bb_preds = None
            is_empty = torch.numel(scores) == 0
            if not is_empty:
                max_score_index = torch.argmax(scores)
                if scores[max_score_index] > th:
                    proba = scores[max_score_index].item()
                    bb_preds = transformed_anchors[max_score_index].cpu().numpy()
                else:
                    proba = scores[max_score_index].item()

            target_labels.append(target_label)
            pred_proba.append(proba)

            plot_concept_detector_results(
                image_to_save, image_orig, image_name, loc="upper right",
                bb_truth=bb_gt, bb_orig=bb_orig, bb_preds=bb_preds, dpi=500
            )

            t.set_postfix(epoch='{0}'.format(index))
            t.update()

    if args.target_dataset.lower() == 'vindr':
        gt = np.array(target_labels)
        pred = np.array(pred_proba)
        pF = pfbeta_binarized(gt=gt, pred=pred)
        prauc, precision, recall = pr_auc(gt=gt, pred=pred, get_all=True)
        aucroc = auroc(gt=gt, pred=pred)
        auprc = compute_auprc(gt=gt, pred=pred)
        acc = compute_accuracy(gt=torch.from_numpy(gt), pred=torch.from_numpy((pred >= 0.5).astype(int)))
        print(f"mAP: {chk_pt['best_MAP']}")
        print(f"pF: {pF}")
        print(f"precision: {np.mean(precision)}")
        print(f"recall: {np.mean(recall)}")
        print(f"pr_auc: {prauc}")
        print(f"auroc: {aucroc}")
        print(f"auprc: {auprc}")
        print(f"acc: {acc}")

        pickle.dump({
            "mAP": chk_pt['best_MAP'],
            "pF": pF,
            "precision": np.mean(precision),
            "recall": np.mean(recall),
            "pr_auc": prauc,
            "auroc": aucroc,
            "auprc": auprc,
            "acc": acc
        }, open(args.output_path / f"{concept}_results.pkl", "wb"))

    if args.target_dataset.lower() == 'rsna':
        print(_dict)
        with open(
                args.data_dir / f'RSNA_Cancer_Detection/dict_image_name_mapping_{concept}_th_{args.score_threshold}.pkl',
                'wb') as file:
            pickle.dump(_dict, file)

        # If only saving cancer patients dont use it.
        # binary_values = [1 if prob > th else 0 for prob in pred_proba]
        # args.valid_folds[f'Proba_{concept}'] = pred_proba
        # args.valid_folds[f'{concept}'] = binary_values
        # args.valid_folds[f'{concept}_image_ids'] = random_image_ids
        # print(args.valid_folds)
        # print(args.valid_folds.columns)
        # args.valid_folds.to_csv(
        #     args.data_dir / 'RSNA_Cancer_Detection' / f'train_folds_v2_{concept}_th_{args.score_threshold}.csv',
        #     index=False
        # )
        print(f'{args.data_dir}/RSNA_Cancer_Detection')

    torch.cuda.empty_cache()
    gc.collect()


def train_loop(args, device):
    print(f'\n================== fold: {args.cur_fold} training ======================')
    if args.data_frac < 1.0:
        args.train_folds = args.train_folds.sample(frac=args.data_frac, random_state=1, ignore_index=True)
    train_loader, valid_loader, valid_dataset = get_dataset(args)
    print(f'train_loader: {len(train_loader)}', f'valid_loader: {len(valid_dataset)}')

    # Create the model
    if args.arch == 'resnet_18':
        retinanet = resnet18(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                             focal_gamma=args.focal_gamma, pretrained=True)
    elif args.arch == 'resnet_34':
        retinanet = resnet34(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                             focal_gamma=args.focal_gamma, pretrained=True)
    elif args.arch == 'resnet_50':
        retinanet = resnet50(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                             focal_gamma=args.focal_gamma, pretrained=True)
    elif args.arch == 'resnet_101':
        retinanet = resnet101(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                              focal_gamma=args.focal_gamma, pretrained=True)
    elif args.arch == 'clip_resnet101_in_house' or args.arch == 'clip_resnet101_in_house_vindr':
        retinanet = resnet101(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                              focal_gamma=args.focal_gamma, pretrained=False, clip_chk_pt=args.clip_chk_pt,
                              freeze_backbone=args.freeze_backbone)
    elif args.arch == 'resnet_152':
        retinanet = resnet152(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                              focal_gamma=args.focal_gamma, pretrained=True)
    elif args.arch == 'clip_resnet152_in_house' or args.arch == 'clip_resnet152_in_house_vindr':
        retinanet = resnet152(num_classes=len(args.concepts), focal_alpha=args.focal_alpha,
                              focal_gamma=args.focal_gamma, pretrained=False, clip_chk_pt=args.clip_chk_pt,
                              freeze_backbone=args.freeze_backbone)
    else:
        retinanet = RetinaNet_efficientnet(
            num_classes=len(args.concepts), model_type=args.arch, focal_alpha=args.focal_alpha,
            focal_gamma=args.focal_gamma, clip_chk_pt=args.clip_chk_pt, freeze_backbone=args.freeze_backbone,
        )

    print(retinanet)
    retinanet.to(device)
    retinanet.training = True

    optimizer = Adam(retinanet.parameters(), lr=args.lr)
    logger = SummaryWriter(args.tb_logs_path / f'fold{args.cur_fold}')

    best_MAP = 0.

    loss_hist = collections.deque(maxlen=500)
    cls_loss_hist = collections.deque(maxlen=500)
    reg_loss_hist = collections.deque(maxlen=500)
    retinanet.train()
    # retinanet.module.freeze_bn()

    for epoch_num in range(args.epochs):
        start_time = time.time()
        retinanet.train()
        # retinanet.module.freeze_bn()

        start = time.time()
        epoch_loss = []
        epoch_cls_loss = []
        epoch_reg_loss = []
        for iter_num, data in enumerate(train_loader):
            try:
                optimizer.zero_grad()
                img = data["image"].to(device)
                bbox = data["res_bbox_tensor"].to(device)
                batch_size = img.size(0)
                classification_loss, regression_loss = retinanet([img, bbox])

                classification_loss = classification_loss.mean()
                regression_loss = regression_loss.mean()
                loss = classification_loss + regression_loss
                if bool(loss == 0):
                    continue
                loss.backward()
                torch.nn.utils.clip_grad_norm_(retinanet.parameters(), 0.1)
                optimizer.step()
                loss_hist.append(float(loss))
                cls_loss_hist.append(float(classification_loss))
                reg_loss_hist.append(float(regression_loss))

                epoch_loss.append(float(loss))
                epoch_cls_loss.append(float(classification_loss))
                epoch_reg_loss.append(float(regression_loss))
                if iter_num % args.print_freq == 0 or iter_num == (len(train_loader) - 1):
                    print('Epoch: [{0}][{1}/{2}] '
                          'Elapsed {remain:s} '
                          'Classification loss: {cls_loss:1.5f} '
                          'Regression loss: {reg_loss:1.5f} '
                          'Running loss: {run_loss:1.5f} '.format(
                        epoch_num + 1, iter_num, len(train_loader),
                        remain=timeSince(start, float(iter_num + 1) / len(train_loader)),
                        cls_loss=float(classification_loss),
                        reg_loss=float(regression_loss),
                        run_loss=np.mean(loss_hist)
                    ))

                if iter_num % args.log_freq == 0 or iter_num == (len(train_loader) - 1):
                    index = iter_num + len(train_loader) * epoch_num
                    logger.add_scalar('train/iter_loss', np.mean(loss_hist), index)
                    logger.add_scalar('train/iter_cls_loss', np.mean(cls_loss_hist), index)
                    logger.add_scalar('train/iter_reg_loss', np.mean(reg_loss_hist), index)

                del classification_loss
                del regression_loss
            except Exception as e:
                print(e)
                continue

        _, MAP = evaluate(valid_dataset, logger=logger, epoch_num=epoch_num, concepts=args.concepts,
                          retinanet=retinanet, score_threshold=args.score_threshold)
        logger.add_scalar('train/epoch_loss', np.mean(np.array(epoch_loss)), epoch_num)
        logger.add_scalar('train/epoch_cls_loss', np.mean(np.array(epoch_cls_loss)), epoch_num)
        logger.add_scalar('train/epoch_reg_loss', np.mean(np.array(epoch_reg_loss)), epoch_num)
        logger.add_scalar('valid/MAP', MAP, epoch_num)

        elapsed = time.time() - start_time
        print(
            f'Epoch {epoch_num + 1} - avg_train_loss: {np.mean(np.array(epoch_loss)):.4f},  '
            f'time: {elapsed:.0f}s, MAP: {MAP:.4f}'
        )

        torch.save(
            {
                'state_dict': retinanet.state_dict(),
                'MAP': MAP
            },
            args.chk_pt_path / f'{args.model_base_name}_seed_{args.seed}_fold_{args.cur_fold}_epoch_{epoch_num}.pth'
        )

        if best_MAP < MAP:
            best_MAP = MAP
            print(f'Epoch {epoch_num + 1} - Save Best aucroc: {best_MAP:.4f} Model')
            torch.save(
                {
                    'state_dict': retinanet.state_dict(),
                    'best_MAP': best_MAP
                },
                args.chk_pt_path / f'{args.model_base_name}_seed_{args.seed}_'
                                   f'fold_{args.cur_fold}_best_auroc.pth'
            )
    print(f'[Fold{args.cur_fold}] Best MAP: {best_MAP:.4f}')

    torch.cuda.empty_cache()
    gc.collect()


def evaluate(val_dataset, concepts, logger, epoch_num, retinanet, iou_threshold=0.5, score_threshold=0.05,
             max_detections=100):
    """Evaluate a given dataset using a given retinanet.
    # Arguments
        generator       : The generator that represents the dataset to evaluate.
        retinanet           : The retinanet to evaluate.
        iou_threshold   : The threshold used to consider when a
            detection is positive or negative.
        score_threshold : The score confidence threshold to use for detections.
        max_detections  : The maximum number of detections to use per image.
        save_path       : The path to save images with visualized detections to.
    # Returns
        A dict mapping class names to mAP scores.
    """

    # gather all detections and annotations

    num_classes = len(concepts)
    all_detections = _get_detections(
        val_dataset,
        retinanet,
        num_classes=num_classes,
        score_threshold=score_threshold,
        max_detections=max_detections,
    )
    all_annotations = _get_annotations(val_dataset)

    average_precisions = {}
    for label in range(num_classes):
        false_positives = np.zeros((0,))
        true_positives = np.zeros((0,))
        scores = np.zeros((0,))
        num_annotations = 0.0

        for i in range(len(val_dataset)):
            detections = all_detections[i][label]
            annotations = all_annotations[i][label]
            num_annotations += annotations.shape[0]
            detected_annotations = []

            for d in detections:
                scores = np.append(scores, d[4])

                if annotations.shape[0] == 0:
                    false_positives = np.append(false_positives, 1)
                    true_positives = np.append(true_positives, 0)
                    continue

                overlaps = compute_overlap(np.expand_dims(d, axis=0), annotations)
                assigned_annotation = np.argmax(overlaps, axis=1)
                max_overlap = overlaps[0, assigned_annotation]

                if (
                        max_overlap >= iou_threshold
                        and assigned_annotation not in detected_annotations
                ):
                    false_positives = np.append(false_positives, 0)
                    true_positives = np.append(true_positives, 1)
                    detected_annotations.append(assigned_annotation)
                else:
                    false_positives = np.append(false_positives, 1)
                    true_positives = np.append(true_positives, 0)

        # no annotations -> AP for this class is 0 (is this correct?)
        if num_annotations == 0:
            average_precisions[label] = 0, 0
            continue

        # sort by score
        indices = np.argsort(-scores)
        false_positives = false_positives[indices]
        true_positives = true_positives[indices]

        # compute false positives and true positives
        false_positives = np.cumsum(false_positives)
        true_positives = np.cumsum(true_positives)

        # compute recall and precision
        recall = true_positives / num_annotations
        precision = true_positives / np.maximum(
            true_positives + false_positives, np.finfo(np.float64).eps
        )

        # compute average precision
        average_precision = _compute_ap(recall, precision)
        average_precisions[label] = average_precision, num_annotations

    print("\nmAP:")
    MAP = 0
    mAPs = []
    _range = range(1, num_classes) if 'No Finding' in concepts else range(0, num_classes)
    for label in _range:
        label_name = concepts[label]
        MAP = average_precisions[label][0]
        mAPs.append(MAP)
        logger.add_scalar(f'valid/{label_name}_mAP', MAP, epoch_num)
        print("{}: {}".format(label_name, average_precisions[label][0]))

    return average_precisions, np.mean(np.array(mAPs))
