import matplotlib as mpl
import matplotlib.patches as patches
import matplotlib.pyplot as plt
from skimage.transform import resize


def create_barplot(
        x_data, y_data, fig_size, plt_title, color, x_label, y_label, x_rotation, y_rotation, save_path, dpi
):
    plt.style.use("ggplot")
    fig, ax = plt.subplots(figsize=fig_size)
    ax.bar(x_data, y_data, color=color, edgecolor='black')
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(plt_title)
    plt.xticks(rotation=x_rotation)
    plt.yticks(rotation=y_rotation)
    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight', dpi=dpi)


def plot_histogram(
        data_arr, title, x_label, y_label, save_path, dpi, figsize=(8, 6), bins=256, range=(0, 256), hist_color='blue',
        hist_alpha=0.7, x_lim=(0, 256), title_font=16, x_label_font=14, y_label_font=14, legend_loc='upper right'
):
    plt.style.use("ggplot")
    fig, ax = plt.subplots(figsize=figsize)
    for data in data_arr:
        ax.hist(data, bins=bins, range=range, color=hist_color, alpha=hist_alpha)

    ax.set_xlim(x_lim)
    ax.set_title(title, fontsize=title_font)
    ax.set_xlabel(x_label, fontsize=x_label_font)
    ax.set_ylabel(y_label, fontsize=y_label_font)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.legend(loc=legend_loc)
    plt.tight_layout()

    plt.savefig(save_path, bbox_inches='tight', dpi=dpi)


def plot_grad_cam_image_with_bounding_boxes(image, xmin, ymin, width, height, image_name, dpi=500):
    fig, ax = plt.subplots(1)
    ax.imshow(image, cmap=plt.cm.bone)
    rect = patches.Rectangle(
        (xmin, ymin), width, height, linewidth=3, edgecolor='r', facecolor='none'
    )
    ax.add_patch(rect)
    plt.axis('off')
    plt.savefig(image_name, bbox_inches='tight', dpi=dpi)


def plot_grad_cam_image(image, heatmap, image_name, dpi=500):
    plt.subplot(1, 2, 1)
    cmap = mpl.cm.get_cmap('jet', 256)
    heatmap_j = resize(heatmap, (1520, 912), preserve_range=True)
    heatmap_j2 = cmap(heatmap_j, alpha=0.2)

    plt.axis('off')
    plt.imshow(image, cmap=plt.cm.bone)
    plt.imshow(heatmap_j2, cmap=plt.cm.bone)
    plt.savefig(image_name, bbox_inches='tight', dpi=dpi)


def plot_grad_cam_image_with_bounding_boxes_and_heatmap(
        dicom_image, png_image, heatmap, bounding_box_gt, bounding_box_orig, bounding_box_pred, image_name,
        dpi=500, loc='upper right'
):
    fig, ax = plt.subplots(1, 2, figsize=(10, 5))
    ax[0].imshow(png_image, cmap=plt.cm.bone)

    width = bounding_box_gt[2] - bounding_box_gt[0]
    height = bounding_box_gt[3] - bounding_box_gt[1]

    rect_gt = patches.Rectangle(
        (bounding_box_gt[0], bounding_box_gt[1]), width, height, linewidth=3, edgecolor='r', facecolor='none',
        label='Ground Truth'
    )
    ax[0].add_patch(rect_gt)

    cmap = mpl.cm.get_cmap('jet', 256)
    heatmap_j = resize(heatmap, (1520, 912), preserve_range=True)
    heatmap_j2 = cmap(heatmap_j, alpha=0.2)
    ax[0].imshow(heatmap_j2, cmap=plt.cm.bone)

    width = bounding_box_pred[2] - bounding_box_pred[0]
    height = bounding_box_pred[3] - bounding_box_pred[1]
    rect_pred = patches.Rectangle(
        (bounding_box_pred[0], bounding_box_pred[1]), width, height, linewidth=3, edgecolor='b', facecolor='none',
        label='Predicted')
    ax[0].add_patch(rect_pred)

    ax[0].set_title('Transformed Image')
    ax[0].axis('off')
    handles, labels = ax[0].get_legend_handles_labels()
    if handles:
        ax[0].legend(loc=loc, borderaxespad=0., framealpha=0.5)

    ax[1].imshow(dicom_image, cmap=plt.cm.bone)
    width = bounding_box_orig[2] - bounding_box_orig[0]
    height = bounding_box_orig[3] - bounding_box_orig[1]
    rect = patches.Rectangle(
        (bounding_box_orig[0], bounding_box_orig[1]), width, height, linewidth=3, edgecolor='r', facecolor='none'
    )
    ax[1].add_patch(rect)
    ax[1].set_title('Original Image')
    ax[1].axis('off')
    plt.tight_layout()
    plt.savefig(image_name, bbox_inches='tight', dpi=dpi)


def plot_concept_detector_results(
        image_to_save, image_orig, image_name, loc="upper right", bb_truth=None, bb_orig=None, bb_preds=None, dpi=500
):
    fig, ax = plt.subplots(1, 2, figsize=(10, 5))
    ax[0].imshow(image_to_save, cmap=plt.cm.bone)

    bounding_box = [bb_truth[0][0], bb_truth[0][1], bb_truth[0][2], bb_truth[0][3]]
    width = bounding_box[2] - bounding_box[0]
    height = bounding_box[3] - bounding_box[1]

    rect = patches.Rectangle(
        (bounding_box[0], bounding_box[1]), width, height, linewidth=3, edgecolor='r', facecolor='none',
        label='Ground Truth'
    )
    ax[0].add_patch(rect)
    ax[0].set_title('Transformed Image')
    ax[0].axis('off')

    if bb_preds is not None:
        bounding_box_pred = [bb_preds[0], bb_preds[1], bb_preds[2], bb_preds[3]]
        width_pred = bounding_box_pred[2] - bounding_box_pred[0]
        height_pred = bounding_box_pred[3] - bounding_box_pred[1]
        rect_pred = patches.Rectangle((bounding_box_pred[0], bounding_box_pred[1]), width_pred, height_pred,
                                      linewidth=3, edgecolor='b', facecolor='none', label='Predicted')

        ax[0].add_patch(rect_pred)

    handles, labels = ax[0].get_legend_handles_labels()
    if handles:
        ax[0].legend(loc=loc, borderaxespad=0., framealpha=0.5)

    ax[1].imshow(image_orig, cmap=plt.cm.bone)
    bounding_box = [bb_orig[0], bb_orig[1], bb_orig[2], bb_orig[3]]
    width = bounding_box[2] - bounding_box[0]
    height = bounding_box[3] - bounding_box[1]
    rect = patches.Rectangle(
        (bounding_box[0], bounding_box[1]), width, height, linewidth=3, edgecolor='r', facecolor='none',
        label='Ground Truth'
    )
    ax[1].add_patch(rect)
    ax[1].set_title('Original Image')
    ax[1].axis('off')
    plt.savefig(image_name, bbox_inches='tight', dpi=dpi)
