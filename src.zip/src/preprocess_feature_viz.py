import os
import argparse

from breast_clip_interpretability.preprocess import generate_attribute_embs


def main():
    parser = argparse.ArgumentParser(
        description="Preprocessing functions."
    )
    parser.add_argument(
        "--breast-clip-path",
        default="/Breast-CLIP/src/codebase/outputs/in_house_clip/b5_detector_period_n/checkpoints/fold_0/model-best-epoch-7.tar",
        type=str
    )
    parser.add_argument(
        "--model",
        type=str,
        default="b5",
        required=False,
        help="Directory where data is stored",
    )
    parser.add_argument(
        "--data_dir",
        type=str,
        default="/Multimodal-mistakes-debug/out/ViNDr/Interpretability/Sent_Emb",
        required=False,
        help="Directory where data is stored",
    )
    args = parser.parse_args()
    os.makedirs(args.data_dir, exist_ok=True)

    print("Generating attribute embeddings")
    generate_attribute_embs(args.data_dir, args.breast_clip_path, args.model)
    print(f"-----------")


if __name__ == "__main__":
    main()
