import math
import os
import random
import re
import time
from collections import defaultdict
from pathlib import Path
import torch.nn as nn
import nltk
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer

import prompts


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def get_device(args):
    return "cuda" if args.device == "cuda" else 'cpu'


def seed_all(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


def get_Paths(args):
    chk_pt_path = Path(f"{args.checkpoints}/{args.dataset}/{args.model_type}/{args.arch}/{args.root}")
    output_path = Path(f"{args.output_path}/{args.dataset}/{args.model_type}/{args.arch}/{args.root}")
    tb_logs_path = Path(f"{args.tensorboard_path}/{args.dataset}/{args.model_type}/{args.arch}/{args.root}")

    return chk_pt_path, output_path, tb_logs_path


def get_constant_prompts(prompt_dict):
    _prompts = {}
    for k in prompt_dict:
        _prompts[k] = [prompt_dict[k]]

    return _prompts


def get_prompts(args):
    if args.concept_prompt_type.lower() == "constant":
        return get_constant_prompts(prompts.NIH_PNEUMOTHORAX_CONST_PROMPTS)
    elif args.concept_prompt_type.lower() == "explanation":
        return get_constant_prompts(prompts.NIH_PNEUMOTHORAX_EXPLANATION_PROMPTS)
    elif args.concept_prompt_type.lower() == "report":
        return prompts.NIH_PNEUMOTHORAX_REPORTS_PROMPTS
    elif args.concept_prompt_type.lower() == "raw_report":
        return prompts.NIH_PNEUMOTHORAX_RAW_REPORTS_PROMPTS


def process_class_prompts(cls_prompts):
    tokenizer = AutoTokenizer.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")
    tokenizer.model_max_length = 77
    cls_prompt_inputs = defaultdict()
    for k, v in cls_prompts.items():
        text_inputs = tokenizer(v, truncation=True, padding=True, return_tensors='pt')
        cls_prompt_inputs[k] = text_inputs
    return cls_prompt_inputs


def _split_report_into_segment(report):
    """clean up raw reports into sentences"""
    if pd.isnull(report):
        return []
    else:
        report = report.replace("\n", " ")
        # splitter = re.compile("[0-9]+\.")
        splitter = re.compile("[0-9]+\.+[^0-9]")
        report = splitter.split(report)
        reports = [point.split(". ") for point in report]
        # reports = [point.split(".") for point in report]
        reports = [sent for point in reports for sent in point]
        study_sent = []
        for sent in reports:
            if len(sent) == 0:
                continue

            sent = sent.replace("\ufffd\ufffd", " ")
            # tokenizer = RegexpTokenizer(r"\w+")
            # tokens = tokenizer.tokenize(sent.lower())

            tokens = nltk.wordpunct_tokenize(sent.lower())

            if len(tokens) <= 1:
                continue

            # filter tokens for current sentence
            included_tokens = []
            for t in tokens:
                t = t.encode("ascii", "ignore").decode("ascii")
                if len(t) > 0:
                    included_tokens.append(t)

            if len(included_tokens) > 4:  # only include relative long sentences
                study_sent.append(" ".join(included_tokens))
        return study_sent


def _split_report_into_segment_concat(report):
    """clean up raw reports into sentences"""
    if pd.isnull(report):
        return []
    else:
        report = report.replace("\n", " ")
        # splitter = re.compile("[0-9]+\.")
        splitter = re.compile("[0-9]+\.+[^0-9]")
        report = splitter.split(report)
        reports = [point.split(". ") for point in report]
        # reports = [point.split(".") for point in report]
        reports = [sent for point in reports for sent in point]
        study_sent = []
        for sent in reports:
            if len(sent) == 0:
                continue

            sent = sent.replace("\ufffd\ufffd", " ")
            # tokenizer = RegexpTokenizer(r"\w+")
            # tokens = tokenizer.tokenize(sent.lower())

            tokens = nltk.wordpunct_tokenize(sent.lower())

            if len(tokens) <= 1:
                continue

            # filter tokens for current sentence
            included_tokens = []
            for t in tokens:
                t = t.encode("ascii", "ignore").decode("ascii")
                if len(t) > 0:
                    included_tokens.append(t)

            study_sent.append(" ".join(included_tokens))
        concatenated_string = ""

        for sentence in study_sent:
            # Check if the sentence ends with a period
            if not sentence.endswith('.'):
                sentence += '.'

            # Concatenate the sentence to the result string
            concatenated_string += sentence.strip() + ' '
        return concatenated_string.strip()


def asMinutes(s):
    m = math.floor(s / 60)
    s -= m * 60
    return '%dm %ds' % (m, s)


def timeSince(since, percent):
    now = time.time()
    s = now - since
    es = s / (percent)
    rs = es - s
    return '%s (remain %s)' % (asMinutes(s), asMinutes(rs))


# def get_gt_pred(model_type, concept, valid_folds):
#     if model_type.lower() == 'domain-classifier':
#         return valid_folds['TARGET'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'biopsy-clip':
#         return valid_folds['CLIP'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'architectural_distortion':
#         return valid_folds['Architectural_Distortion'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'asymmetry':
#         return valid_folds['Asymmetry'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'focal_asymmetry':
#         return valid_folds['Focal_Asymmetry'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'global_asymmetry':
#         return valid_folds['Global_Asymmetry'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'mass':
#         return valid_folds['Mass'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'nipple_retraction':
#         return valid_folds['Nipple_Retraction'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'skin_retraction':
#         return valid_folds['Skin_Retraction'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'skin_thickening':
#         return valid_folds['Skin_Thickening'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'suspicious_calcification':
#         return valid_folds['Suspicious_Calcification'].values, valid_folds['prediction'].values
#     elif model_type.lower() == 'concept-classifier' and concept.lower() == 'suspicious_lymph_node':
#         return valid_folds['Suspicious_Lymph_Node'].values, valid_folds['prediction'].values

def get_gt_pred(args):
    if args.model_type.lower() == 'domain-classifier':
        return args.valid_folds['TARGET'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'biopsy-clip':
        return args.valid_folds['CLIP'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'architectural_distortion':
        return args.valid_folds['Architectural_Distortion'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'asymmetry':
        return args.valid_folds['Asymmetry'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'focal_asymmetry':
        return args.valid_folds['Focal_Asymmetry'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'global_asymmetry':
        return args.valid_folds['Global_Asymmetry'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'mass':
        return args.valid_folds['Mass'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'nipple_retraction':
        return args.valid_folds['Nipple_Retraction'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'skin_retraction':
        return args.valid_folds['Skin_Retraction'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'skin_thickening':
        return args.valid_folds['Skin_Thickening'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'suspicious_calcification':
        return args.valid_folds['Suspicious_Calcification'].values, args.valid_folds['prediction'].values
    elif args.model_type.lower() == 'concept-classifier' and args.concept.lower() == 'suspicious_lymph_node':
        return args.valid_folds['Suspicious_Lymph_Node'].values, args.valid_folds['prediction'].values


def get_cols(args):
    if args.dataset.lower() == 'in_house':
        return {
            'concept': 'CLIP',
            'study_id': 'STUDY_ID',
            'image_id': 'IMAGE_ID',
        }
    elif args.dataset.lower() == 'vindr':
        return {
            'concept': {args.concept},
            'study_id': 'study_id',
            'image_id': 'image_id',
        }