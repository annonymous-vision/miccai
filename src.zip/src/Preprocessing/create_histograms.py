import argparse
import os
import shutil
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from tqdm import tqdm

sys.path.append(os.path.abspath("/Multimodal-mistakes-debug"))


def config():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', metavar='DIR',
                        default='/Multimodal-mistakes-debug/',
                        help='path to first dataset')
    parser.add_argument('--dataset1_path', metavar='DIR',
                        default='/RSNA_Breast_Imaging/Dataset/External/in_house/images_flipped_like_dicom_normalized_monochrome',
                        help='path to first dataset')
    parser.add_argument('--dataset2_path', metavar='DIR',
                        default='/RSNA_Breast_Imaging/Dataset/External/Vindr/vindr-mammo-a-large-scale-benchmark-dataset-for-computer-aided-detection-and-diagnosis-in-full-field-digital-mammography-1.0.0/images_png',
                        help='path to second dataset')
    parser.add_argument(
        '--dataset1_name', default='in_house (flipped-normalized-monochrome)', help='name of the first dataset'
    )
    parser.add_argument(
        '--dataset2_name', default='VINDr', help='name of the first dataset'
    )
    parser.add_argument('--chunk_size', default=100, type=int)

    return parser.parse_args()


def plot_histogram(
        data_arr, title, x_label, y_label, save_path, dpi, figsize=(8, 6), bins=256, range=(0, 256), hist_color='blue',
        hist_alpha=0.7, x_lim=(0, 256), title_font=16, x_label_font=14, y_label_font=14, legend_loc='upper right'
):
    plt.style.use("ggplot")
    fig, ax = plt.subplots(figsize=figsize)
    for data in data_arr:
        print(data)
        ax.hist(data, bins=bins, range=range, color=hist_color, alpha=hist_alpha)

    ax.set_xlim(x_lim)
    ax.set_title(title, fontsize=title_font)
    ax.set_xlabel(x_label, fontsize=x_label_font)
    ax.set_ylabel(y_label, fontsize=y_label_font)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.legend(loc=legend_loc)
    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight', dpi=dpi)


def plot_histograms(data1, data2, title, xlabel, ylabel, legend_labels, save_path):
    fig, ax = plt.subplots(figsize=(12, 6))

    # Plot histogram for data1
    ax.hist(data1, bins=256, range=(0, 256), color='blue', alpha=0.7, label=legend_labels[0])

    # Plot histogram for data2
    ax.hist(data2, bins=256, range=(0, 256), color='red', alpha=0.7, label=legend_labels[1])

    ax.set_xlim([0, 256])
    ax.set_ylim([0, 20])
    ax.set_title(title, fontsize=16)
    ax.set_xlabel(xlabel, fontsize=14)
    ax.set_ylabel(ylabel, fontsize=14)
    ax.legend(loc='upper right')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.savefig(save_path, bbox_inches='tight', dpi=500)


# Assuming datase

def process_images_in_chunks(images, chunk_size):
    num_images = len(images)
    num_chunks = num_images // chunk_size
    histograms = []

    for i in tqdm(range(num_chunks), desc='Processing chunks'):
        start_idx = i * chunk_size
        end_idx = (i + 1) * chunk_size
        chunk_images = images[start_idx:end_idx]
        combined_chunk = np.concatenate([np.array(img).ravel() for img in chunk_images])
        histogram, _ = np.histogram(combined_chunk, bins=256, range=(0, 256))
        histograms.append(histogram)

    remaining_images = images[num_chunks * chunk_size:]
    if remaining_images:
        combined_chunk = np.concatenate([np.array(img).ravel() for img in remaining_images])
        histogram, _ = np.histogram(combined_chunk, bins=256, range=(0, 256))
        histograms.append(histogram)

    combined_histogram = np.sum(histograms, axis=0)
    return combined_histogram


def load_and_process_images(dataset_path, chunk_size):
    dataset_images = []
    combined_histogram_dataset = None

    # Process dataset1 images in chunks
    for filename in tqdm(os.listdir(dataset_path), desc=f"Loading images from {dataset_path}"):
        if filename.endswith(('.jpg', '.png')):
            image_path = dataset_path / filename
            img = Image.open(image_path)
            dataset_images.append(img)
            if len(dataset_images) == chunk_size:
                print(len(dataset_images))
                combined_histogram_dataset = process_images_in_chunks(dataset_images, chunk_size)
                dataset_images = []

    # Process any remaining dataset images
    if dataset_images:
        print(len(dataset_images))
        combined_histogram_dataset = process_images_in_chunks(dataset_images, chunk_size)

    return combined_histogram_dataset


def move_images_to_temp_folder(root, dataset_path, dataset_name):
    dataset_path = Path(dataset_path)
    temp_loc = Path(root) / "temp" / dataset_name
    temp_loc.mkdir(parents=True, exist_ok=True)

    idx = 1
    with tqdm() as t:
        for filename in tqdm(os.listdir(dataset_path)):
            files = os.listdir(dataset_path / filename)
            files = [f for f in files if os.path.isfile(dataset_path / filename / f)]
            for file in files:
                if file.endswith(('.jpg', '.png')):
                    image_path = dataset_path / filename / file
                    shutil.copy(image_path, temp_loc / f'{idx}_{file}')
                    idx += 1
                    # if idx == 202:
                    #     break
                    t.set_postfix(idx='{0}'.format(idx))
                    t.update()

            # if idx == 202:
            #     break
    return temp_loc


def main(args):
    # Define chunk size (adjust as needed)
    chunk_size = args.chunk_size

    # Define paths to dataset folders

    temp_loc1 = move_images_to_temp_folder(args.root, args.dataset1_path, args.dataset1_name)
    temp_loc2 = move_images_to_temp_folder(args.root, args.dataset2_path, args.dataset2_name)

    combined_histogram_dataset1 = load_and_process_images(temp_loc1, chunk_size)
    combined_histogram_dataset2 = load_and_process_images(temp_loc2, chunk_size)

    shutil.rmtree(temp_loc1)
    shutil.rmtree(temp_loc2)

    print(len(combined_histogram_dataset1), len(combined_histogram_dataset2))

    save_path = Path(args.root) / "Plots"
    save_path.mkdir(parents=True, exist_ok=True)

    plt_title = f'Combined Histogram of {args.dataset1_name} and {args.dataset2_name}'
    data_arr = [combined_histogram_dataset1, combined_histogram_dataset2]
    # plot_histogram(
    #     data_arr, plt_title, x_label="Pixel Value",
    #     y_label="Frequency", save_path=save_path, dpi=400, figsize=(8, 6), bins=256, range=(0, 256),
    #     hist_color='blue', hist_alpha=0.7, x_lim=(0, 256), title_font=16, x_label_font=14, y_label_font=14
    # )
    plot_histograms(
        combined_histogram_dataset1, combined_histogram_dataset2, plt_title, xlabel='Pixel Value', ylabel='Frequency',
        legend_labels=[args.dataset1_name, args.dataset2_name],
        save_path=f"{save_path}/{args.dataset1_name}_{args.dataset2_name}_combined_histogram.png"
    )

    print(save_path)


if __name__ == "__main__":
    _args = config()
    main(_args)
