import os
import sys

from IPython.core.display import display
from pydicom import dcmread

sys.path.append(os.path.abspath("/RSNA_Breast_Imaging"))
import os
import dicomsdl
from tqdm.auto import tqdm
import numpy as np
import pandas as pd

import torch
import timm
# import nvidia.dali.types as types
import cv2


# from nvidia.dali.plugin.pytorch import feed_ndarray, to_torch_type

# we need to patch DALI for Int16 support
#
# to_torch_type = {
#     types.DALIDataType.FLOAT: torch.float32,
#     types.DALIDataType.FLOAT64: torch.float64,
#     types.DALIDataType.FLOAT16: torch.float16,
#     types.DALIDataType.UINT8: torch.uint8,
#     types.DALIDataType.INT8: torch.int8,
#     types.DALIDataType.UINT16: torch.int16,
#     types.DALIDataType.INT16: torch.int16,
#     types.DALIDataType.INT32: torch.int32,
#     types.DALIDataType.INT64: torch.int64
# }


def np_CountUpContinuingOnes(b_arr):
    # indice continuing zeros from left side.
    # ex: [0,1,1,0,1,0,0,1,1,1,0] -> [0,0,0,3,3,5,6,6,6,6,10]
    left = np.arange(len(b_arr))
    left[b_arr > 0] = 0
    left = np.maximum.accumulate(left)

    # from right side.
    # ex: [0,1,1,0,1,0,0,1,1,1,0] -> [0,3,3,3,5,5,6,10,10,10,10]
    rev_arr = b_arr[::-1]
    right = np.arange(len(rev_arr))
    right[rev_arr > 0] = 0
    right = np.maximum.accumulate(right)
    right = len(rev_arr) - 1 - right[::-1]

    return right - left - 1


def ExtractBreast(img):
    img_copy = img.copy()
    img = np.where(img <= 40, 0, img)  # To detect backgrounds easily
    height, _ = img.shape

    # whether each col is non-constant or not
    y_a = height // 2 + int(height * 0.4)
    y_b = height // 2 - int(height * 0.4)
    b_arr = img[y_b:y_a].std(axis=0) != 0
    continuing_ones = np_CountUpContinuingOnes(b_arr)
    # longest should be the breast
    col_ind = np.where(continuing_ones == continuing_ones.max())[0]
    img = img[:, col_ind]

    # whether each row is non-constant or not
    _, width = img.shape
    x_a = width // 2 + int(width * 0.4)
    x_b = width // 2 - int(width * 0.4)
    b_arr = img[:, x_b:x_a].std(axis=1) != 0
    continuing_ones = np_CountUpContinuingOnes(b_arr)
    # longest should be the breast
    row_ind = np.where(continuing_ones == continuing_ones.max())[0]

    return img_copy[row_ind][:, col_ind]


def save_imgs(in_path, out_path, SIZE=(912, 1520)):
    dicom = dicomsdl.open(in_path)
    try:
        data = dicom.pixelData()
    except Exception as e:
        print(f"An error occurred: {e}")
    data = data[5:-5, 5:-5]
    if dicom.getPixelDataInfo()['PhotometricInterpretation'] == "MONOCHROME1":
        data = np.amax(data) - data

    data = data - np.min(data)
    data = data / np.max(data)
    data = (data * 255).astype(np.uint8)

    img = ExtractBreast(data)
    img = cv2.resize(img, SIZE, interpolation=cv2.INTER_AREA)
    cv2.imwrite(out_path, img)

    # print(out_path)


###############################
### source url: https://www.kaggle.com/code/masato114/rsna-generate-train-images/notebook
###############################
print('torch version:', torch.__version__)
print('timm version:', timm.__version__)
##############################
####### Load data ################
##############################

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device:', device)

train_df = pd.read_csv(
    '/RSNA_Breast_Imaging/Dataset/External/in_house/results.csv')
display(train_df.head(5))
display(train_df.shape)

phase = 'train'  # 'test'

if phase == 'train':
    df = train_df.reset_index(drop=True)

IMG_PATH = f"in_housePatients"
# test_images = glob.glob(f"{IMG_PATH}*/*.dcm")

print("Number of images :", len(df))

SAVE_FOLDER = f'/RSNA_Breast_Imaging/Dataset/External/in_house/DICOM/images_png_CC_MLO'
os.makedirs(SAVE_FOLDER, exist_ok=True)

for patient_id in train_df["STUDY_ID"]:
    _output = os.path.join(SAVE_FOLDER, f"Patient_{str(patient_id)}")
    os.makedirs(_output, exist_ok=True)

_SIZE = (912, 1520)

if len(df) > 100:
    N_CHUNKS = 4
else:
    N_CHUNKS = 1

CHUNKS = [(len(df) / N_CHUNKS * k, len(df) / N_CHUNKS * (k + 1)) for k in range(N_CHUNKS)]
CHUNKS = np.array(CHUNKS).astype(int)

idx = 0
for chunk in tqdm(CHUNKS):
    for patient_id in df.iloc[chunk[0]: chunk[1]]['STUDY_ID'].values:
        _in_path = IMG_PATH + "/" + f"Patient_{str(patient_id)}/DICOM"
        files = os.listdir(_in_path)
        files = [f for f in files if os.path.isfile(os.path.join(_in_path, f))]
        print(files)
        for f in files:
            idx += 1
            print(f"\n=============== {idx} ==================")
            try:
                ds = dcmread(f"{_in_path}/{f}")
                if hasattr(ds, 'ViewPosition'):
                    print(ds.ViewPosition)
                    if ds.ViewPosition == "MLO" or ds.ViewPosition == "CC":
                        image_name = f[:-4] + ".png"
                        _out_path = os.path.join(SAVE_FOLDER, f"Patient_{str(patient_id)}", f"{image_name}")
                        print(f"{_in_path}/{f}")
                        print(_out_path)
                        arr = ds.pixel_array
                        save_imgs(in_path=f"{_in_path}/{f}", out_path=_out_path, SIZE=_SIZE)
            except Exception as e:
                print(f"=================>>> An error occurred: {e} <<<=================,  id: {idx}")
                print('Exception')
                # print(xxxxx)
                continue
            print(f"=============== {idx} ==================\n")
