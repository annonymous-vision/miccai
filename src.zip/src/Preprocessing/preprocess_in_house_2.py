import os
import sys

from IPython.core.display import display

sys.path.append(os.path.abspath("/RSNA_Breast_Imaging"))

import pandas as pd
import numpy as np
import torch
import timm
import cv2
import shutil, os, nibabel

import imageio

def np_CountUpContinuingOnes(b_arr):
    # indice continuing zeros from left side.
    # ex: [0,1,1,0,1,0,0,1,1,1,0] -> [0,0,0,3,3,5,6,6,6,6,10]
    left = np.arange(len(b_arr))
    left[b_arr > 0] = 0
    left = np.maximum.accumulate(left)

    # from right side.
    # ex: [0,1,1,0,1,0,0,1,1,1,0] -> [0,3,3,3,5,5,6,10,10,10,10]
    rev_arr = b_arr[::-1]
    right = np.arange(len(rev_arr))
    right[rev_arr > 0] = 0
    right = np.maximum.accumulate(right)
    right = len(rev_arr) - 1 - right[::-1]

    return right - left - 1


def ExtractBreast(img):
    img_copy = img.copy()
    img = np.where(img <= 40, 0, img)  # To detect backgrounds easily
    height, _ = img.shape

    # whether each col is non-constant or not
    y_a = height // 2 + int(height * 0.4)
    y_b = height // 2 - int(height * 0.4)
    b_arr = img[y_b:y_a].std(axis=0) != 0
    continuing_ones = np_CountUpContinuingOnes(b_arr)
    # longest should be the breast
    col_ind = np.where(continuing_ones == continuing_ones.max())[0]
    img = img[:, col_ind]

    # whether each row is non-constant or not
    _, width = img.shape
    x_a = width // 2 + int(width * 0.4)
    x_b = width // 2 - int(width * 0.4)
    b_arr = img[:, x_b:x_a].std(axis=1) != 0
    continuing_ones = np_CountUpContinuingOnes(b_arr)
    # longest should be the breast
    row_ind = np.where(continuing_ones == continuing_ones.max())[0]

    return img_copy[row_ind][:, col_ind]


def main(inputfile, outputfile, SIZE=(912, 1520), move="y"):
    img_name = inputfile.split('/')
    #     print('Input file is ', inputfile)
    #     print('Output folder is ', outputfile)

    # set fn as your 4d nifti file
    image_array = nibabel.load(inputfile).get_data()
    print(image_array.shape)

    # if 4D image inputted
    # else if 3D image inputted
    if len(image_array.shape) == 3:
        # set 4d array dimension values
        nx, ny, nz = image_array.shape



        # set destination folder
        if not os.path.exists(outputfile):
            os.makedirs(outputfile)
            print("Created ouput directory: " + outputfile)

        print('Reading NIfTI file...')

        total_slices = image_array.shape[2]

        slice_counter = 0
        # iterate through slices
        for current_slice in range(0, total_slices):
            # alternate slices
            if (slice_counter % 1) == 0:
                # rotate or no rotate
                data = image_array[:, :, current_slice]
                data = np.squeeze(data)
                print(data.shape)
                if move == "y":
                    # plt.imshow(data, cmap=plt.cm.bone)
                    # plt.axis('off')  # Turn off axis labels
                    # plt.show()

                    data = np.rot90(image_array[:, :, current_slice])
                    # plt.imshow(data, cmap=plt.cm.bone)
                    # plt.axis('off')  # Turn off axis labels
                    # plt.show()

                    data = np.flip(data, axis=0)
                    # plt.imshow(data, cmap=plt.cm.bone)
                    # plt.axis('off')  # Turn off axis labels
                    # plt.show()
    #                 print(data.shape)
    #                 # Display the image
#                     plt.imshow(data, cmap=plt.cm.bone)
#                     plt.axis('off')  # Turn off axis labels
#                     plt.show()

                # move images to folder
                print('Saving image...')
                image_name = img_name[-1][:-4] + ".png"
                data = data[5:-5, 5:-5]
                print(data.shape)
                data = np.amax(data) - data

                data = data - np.min(data)
                data = data / np.max(data)
#                 print(data)
                data = (data * 255).astype(np.uint8)
                img = ExtractBreast(data)
                img = cv2.resize(img, SIZE, interpolation=cv2.INTER_AREA)
#                 print(img.shape)
                cv2.imwrite(f"{outputfile}/{image_name}", img)
                
#                 plt.imshow(img, cmap=plt.cm.bone)
#                 plt.axis('off')  # Turn off axis labels
#                 plt.show()
#                 # imageio.imwrite(image_name, data)
#                 print('Saved.')
#                 print(img)
              

                # move images to folder
#                 print('Moving files...')
                # src = image_name
                # shutil.move(src, outputfile)
                # slice_counter += 1
                # print('Moved.')





###############################
### source url: https://www.kaggle.com/code/masato114/rsna-generate-train-images/notebook
###############################
print('torch version:', torch.__version__)
print('timm version:', timm.__version__)
##############################
####### Load data ################
##############################

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device:', device)

# test_df = pd.read_csv(
#     '/RSNA_Breast_Imaging/Dataset/RSNA_Cancer_Detection/test.csv')
result_df = pd.read_csv(
    '/RSNA_Breast_Imaging/Dataset/External/in_house/result.csv'
)
# display(test_df.head())
display(result_df.shape)

_path1 = "in_housePatients/Patient_"
# _output1 = "/RSNA_Breast_Imaging/Dataset/External/in_house/images/Patient_"
_output1 = "/RSNA_Breast_Imaging/Dataset/External/in_house/images_flipped_like_dicom_normalized_monochrome/Patient_"
# Filter out directories (if needed)

for patient in result_df["STUDY_ID"]:
    _path = _path1 + f"{str(patient)}/NIFTI"
    _output = _output1 + f"{str(patient)}"
    os.makedirs(_output, exist_ok=True)

    files = os.listdir(_path)
    files = [f for f in files if os.path.isfile(os.path.join(_path, f))]
    print(files)
    #     print(xxxx)
    for f in files:
        print("\n=================================")
        print(f"{_path}/{f}")
        print(_output)
        main(f"{_path}/{f}", _output, move='y')
