import torch

from Classifiers.models.ResNet import ResNet
from Classifiers.models.custom_densenet121 import DenseNet
from breastclip.data import DataModule
from breastclip.model import build_model

def get_densenet_params(arch):
    assert 'dense' in arch
    if arch == 'densenet161':
        ret = dict(growth_rate=48, block_config=(6, 12, 36, 24), num_init_features=96)
    elif arch == 'densenet169':
        ret = dict(growth_rate=32, block_config=(6, 12, 32, 32), num_init_features=64)
    elif arch == 'densenet201':
        ret = dict(growth_rate=32, block_config=(6, 12, 48, 32), num_init_features=64)
    else:
        # default configuration: densenet121
        ret = dict(growth_rate=32, block_config=(6, 12, 24, 16), num_init_features=64)

    return ret


def get_models(args):
    if args.arch == "densenet121" and args.dataset == "NIH":
        return DenseNet(
            num_classes=args.num_classes, in_channels=args.channel, drop_rate=args.drop_rate, weights=args.weights,
            return_logit=args.return_logit,
            **get_densenet_params(args.arch)
        )
    elif args.arch.lower() == "resnet50" or args.arch.lower() == "resnet101" or args.arch.lower() == "resnet152":
        return ResNet(
            pre_trained=True, n_class=args.num_classes, model_choice=args.arch, weights=args.weights,
            return_logit=args.return_logit
        )


def get_train_configs(args):
    optimizer = None
    criterion = None

    if args.optimizer == "sgd" and args.dataset == "NIH":
        optimizer = torch.optim.SGD(args.model.parameters(), lr=args.lr, momentum=0.9, weight_decay=args.weight_decay)
    elif args.optimizer == "adam" and args.dataset == "NIH":
        optimizer = torch.optim.Adam(args.model.parameters(), lr=args.lr, weight_decay=args.weight_decay, amsgrad=True)

    if args.loss == "BCE":
        criterion = torch.nn.BCEWithLogitsLoss()
    elif args.loss == "BCE_W" and args.dataset == "NIH":
        pos_wt = torch.tensor([args.pos_weights[0]]).to('cuda')
        criterion = torch.nn.BCEWithLogitsLoss(pos_weight=pos_wt)

    return optimizer, criterion
