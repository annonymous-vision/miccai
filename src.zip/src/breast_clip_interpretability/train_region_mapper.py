import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import time
from Datasets.dataset_utils import get_dataloader_Vindr
from breast_clip_interpretability.mapper_loss import Mapper_loss
from breast_clip_interpretability.mapper_model import Mapper_model
from breastclip.data import DataModule
from breastclip.model import build_model

from tqdm import tqdm


def train_region_mapper(args, device):
    print(f"=> Training is getting started")
    # Initialize dataloaders
    args.data_dir = Path(args.data_dir)
    args.df = pd.read_csv(args.data_dir / args.csv_file)
    args.df = args.df.fillna(0)
    args.df = args.df[(args.df["Mass"] == 1) | (args.df["Suspicious_Calcification"] == 1)]
    print(f"df shape: {args.df.shape}")
    print(args.df.columns)
    args.train_folds = args.df[args.df['split'] == "training"].reset_index(drop=True)
    args.valid_folds = args.df[args.df['split'] == "test"].reset_index(drop=True)
    train_loader, val_loader = get_dataloader_Vindr(args)
    print(f'train_loader: {len(train_loader)}, valid_loader: {len(val_loader)}')

    print(args.clip_chk_pt_path)

    ckpt = torch.load(args.clip_chk_pt_path, map_location="cpu")

    # Initialize model, loss, and optimizer
    attr_embs = torch.load(args.attr_embs_path)
    model = Mapper_model(
        ckpt, lang_emb=args.lang_emb, emb_dim=args.img_emb, one_proj=False, adapter=False, attr_embs=attr_embs
    ).to("cuda")
    loss = Mapper_loss(temp=0.07, one_proj=False, attr_to_embs=attr_embs)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)
    print(
        f"=> Using model {type(model).__name__} with loss {type(loss).__name__} on {torch.cuda.device_count()} GPUs"
    )

    # Train Mapper model
    print(f"=> Training Mapper model")
    train(
        model,
        loss,
        opt,
        None,
        train_loader,
        val_loader,
        args.epochs,
        args.batch_size,
        device,
        args.chk_pt_path,
        False,
    )


def train(
        model,
        loss_fn,
        opt,
        scheduler,
        train_loader,
        val_loader,
        epochs,
        batch_size,
        device,
        chk_pt_path,
        early_stop=False,
):
    """
    Training loop.

    Parameters:
        model (torch.nn.Module): Model
        loss_fn (torch.nn.Module): Loss function
        opt (torch.optim): Optimizer
        scheduler (torch.optim.lr_scheduler): LR scheduler (set to None if no scheduler)
        train_loader (torch.utils.data.DataLoader): Dataloader for training data
        val_loader (torch.utils.data.DataLoader): Dataloader for validation data
        epochs (int): Number of training epochs
        batch_size (int): Batch size
        checkpoint_dir (str): Directory for storing model weights
        early_stop (bool): True if early stopping based on validation loss
    """
    scaler = torch.cuda.amp.GradScaler()
    epochs_no_improvements = 0
    best_val_loss = np.inf

    for epoch in range(0, epochs):
        model.train()
        time_start = time.time()
        progress_iter = tqdm(enumerate(train_loader), desc=f"[{epoch + 1:03d}/{epochs:03d} epoch train]",
                             total=len(train_loader))
        for step, sample in progress_iter:
            opt.zero_grad()

            with torch.cuda.amp.autocast(enabled=True):
                pred = model(sample)

            loss = loss_fn(pred, sample)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            # summary = (
            #     "\r[Epoch {}][Step {}/{}] Loss: {}, Lr: {} - {:.2f} m remaining".format(
            #         epoch + 1,
            #         step,
            #         int(len(train_loader.dataset) / batch_size),
            #         "{}: {:.2f}".format(
            #             type(loss_fn).__name__, loss_fn.mean_running_loss
            #         ),
            #         *[group["lr"] for group in opt.param_groups],
            #         ((time.time() - time_start) / (step + 1))
            #         * ((len(train_loader.dataset) / batch_size) - step)
            #         / 60,
            #     )
            # )
            # print(summary)

            progress_iter.set_postfix(
                {
                    "lr": [opt.param_groups[0]['lr']],
                    "loss": f"{loss_fn.mean_running_loss:.4f}",
                    "CUDA-Mem": f"{torch.cuda.memory_usage(device)}%",
                    "CUDA-Util": f"{torch.cuda.utilization(device)}%",
                }
            )
        time_end = time.time()
        elapse_time = time_end - time_start
        print("Finished in {}s".format(int(elapse_time)))

        torch.save(model.state_dict(), os.path.join(chk_pt_path, f"epoch_{epoch + 1}.pkl"))

        val_loss = evaluate(model, epoch, epochs, loss_fn, val_loader, device)
        epochs_no_improvements += 1
        if val_loss < best_val_loss:
            print("Saving best model")
            torch.save(
                model.state_dict(), os.path.join(chk_pt_path, f"best.pkl")
            )
            epochs_no_improvements = 0
            best_val_loss = val_loss

        if scheduler:
            scheduler.step(val_loss)

        if epochs_no_improvements == 5:
            print("Early stop reached")
            return


def evaluate(model, epoch, epochs, loss_fn, val_loader, device, split="val"):
    """
    Validation loop.

    Parameters:
        model (torch.nn.Module): Model
        loss_fn (torch.nn.Module): Loss function
        val_loader (torch.utils.data.DataLoader): Dataloader for validation data
        split (str): Evaluation split
    Returns:
        loss (torch.Tensor): Validation loss
    """
    print(f"Evaluating on {split}")
    model.eval()

    running_loss = 0
    num_batches = 0
    with torch.no_grad():
        progress_iter = tqdm(enumerate(val_loader), desc=f"[{epoch + 1:03d}/{epochs:03d} epoch train]",
                             total=len(val_loader))
        for step, sample in progress_iter:
            pred = model(sample)

            running_loss += loss_fn(pred, sample)
            num_batches += 1

            progress_iter.set_postfix(
                {
                    "loss": f"{running_loss:.4f}",
                    "CUDA-Mem": f"{torch.cuda.memory_usage(device)}%",
                    "CUDA-Util": f"{torch.cuda.utilization(device)}%",
                }
            )

    loss = running_loss / num_batches
    print(f"Eval Loss = {loss}")
    return loss
