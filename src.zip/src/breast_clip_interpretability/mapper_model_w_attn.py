import torch
import torch.nn as nn
from torch.nn import LayerNorm, Linear, MultiheadAttention

from breastclip.model.modules import load_image_encoder


class Mapper_w_attn(nn.Module):
    def __init__(self, ckpt, image_embedding_size, text_embedding_size, text_embeddings, num_classes=2, num_heads=8):
        super(Mapper_w_attn, self).__init__()
        self.text_embeddings = text_embeddings
        self.image_encoder = load_image_encoder(ckpt["config"]["model"]["image_encoder"])
        image_encoder_weights = {}
        for k in ckpt["model"].keys():
            if k.startswith("image_encoder."):
                image_encoder_weights[".".join(k.split(".")[1:])] = ckpt["model"][k]
        self.image_encoder.load_state_dict(image_encoder_weights, strict=True)
        self.image_encoder_type = ckpt["config"]["model"]["image_encoder"]["model_type"]
        for param in self.image_encoder.parameters():
            param.requires_grad = False

        self.text_projection = Linear(text_embedding_size, image_embedding_size)
        self.self_attention = MultiheadAttention(embed_dim=image_embedding_size, num_heads=num_heads)
        self.norm = LayerNorm(image_embedding_size)
        self.cross_attention = MultiheadAttention(embed_dim=image_embedding_size, num_heads=num_heads)
        self.classifier = Linear(image_embedding_size, num_classes)



    def forward(self, sample):
        img_vector = sample["img"].to(torch.float32).to("cuda")
        img_vector = img_vector.squeeze(1).permute(0, 3, 1, 2)
        image_embeddings = self.image_encoder(img_vector)

        # Project text embeddings to match image embedding size
        text_embeddings = self.text_projection(self.text_embeddings)

        # Apply self-attention to text embeddings
        text_embeddings, _ = self.self_attention(text_embeddings, text_embeddings, text_embeddings)

        # Normalize embeddings
        image_embeddings = self.norm(image_embeddings)
        text_embeddings = self.norm(text_embeddings)

        attention_output, _ = self.cross_attention(query=image_embeddings, key=text_embeddings, value=text_embeddings)
        logits = self.classifier(attention_output)
        return logits
