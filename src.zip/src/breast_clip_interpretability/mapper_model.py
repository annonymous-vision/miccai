import torch

from breastclip.model.modules import load_image_encoder


class Mapper_model(torch.nn.Module):
    def __init__(self, ckpt, lang_emb: int, emb_dim: int, one_proj: bool, adapter: bool, attr_embs):
        """
        Initialize model for ViLLA Stage 1.

        Parameters:
            emb_dim (int): Embedding dimension
            one_proj (bool): True if using one projection head, False otherwise
            adapter (bool): True if using an adapter approach
            data_dir (str): Filepath to directory with data
        """
        super(Mapper_model, self).__init__()
        self.image_encoder = load_image_encoder(ckpt["config"]["model"]["image_encoder"])
        image_encoder_weights = {}
        for k in ckpt["model"].keys():
            if k.startswith("image_encoder."):
                image_encoder_weights[".".join(k.split(".")[1:])] = ckpt["model"][k]
        self.image_encoder.load_state_dict(image_encoder_weights, strict=True)
        self.image_encoder_type = ckpt["config"]["model"]["image_encoder"]["model_type"]
        for param in self.image_encoder.parameters():
            param.requires_grad = False

        self.emb_dim = emb_dim
        self.lang_emb = lang_emb
        self.one_proj = one_proj
        self.adapter = adapter

        # Initialize projection heads
        if self.one_proj:
            self.num_proj = 1
        else:
            self.num_proj = len(attr_embs)
        self.pool = torch.nn.ModuleList(
            [
                torch.nn.Sequential(
                    torch.nn.Linear(self.emb_dim, self.emb_dim),
                    torch.nn.ReLU(),
                    torch.nn.Linear(self.emb_dim, self.lang_emb),
                )
                for i in range(self.num_proj)
            ]
        )

    def encode_image(self, input):
        image_features, raw_features = self.image_encoder(input)
        return image_features, raw_features

    def forward(self, sample: dict):
        """
        Run model forward pass.

        Parameters:
            sample (dict): Data associated with each sample
        Returns:
            out_dict (dict): Consists of outputs of the projection heads
                             for each region
        """
        out_dict = {}

        img_vector = sample["img"].to(torch.float32).to("cuda")
        if len(img_vector.size()) == 5:
            img_vector = img_vector.squeeze(1).permute(0, 3, 1, 2)
        input = {"image": img_vector}

        image_features, raw_features = self.encode_image(input)
        bs = raw_features.size(0)
        channel_dim = raw_features.size(1)
        raw_features_flatten = raw_features.view(bs, channel_dim, -1)

        out_img_a = []
        for i in range(self.num_proj):
            pool = self.pool[i](raw_features_flatten)
            if self.adapter:
                pool = 0.2 * pool + 0.8 * raw_features_flatten
            out_img_a.append(pool)

        region_proj_embs = torch.cat(out_img_a, dim=1).view(
            -1, self.num_proj, self.lang_emb
        )
        out_dict["region_proj_embs"] = region_proj_embs
        out_dict["num_regions"] = torch.tensor(channel_dim)
        out_dict["image_features"] = image_features
        out_dict["raw_features"] = raw_features
        return out_dict
