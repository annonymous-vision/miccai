from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import roc_auc_score
from torch.optim import Adam
from tqdm import tqdm

from Datasets.dataset_utils import get_dataloader_Vindr
from breast_clip_interpretability.mapper_model_w_attn import Mapper_w_attn


def train_region_mapper_w_attn(args, device):
    print(f"=> Training is getting started")
    # Initialize dataloaders
    args.data_dir = Path(args.data_dir)
    args.df = pd.read_csv(args.data_dir / args.csv_file)
    args.df = args.df.fillna(0)
    # args.df = args.df[(args.df["Mass"] == 1) | (args.df["Suspicious_Calcification"] == 1)]
    print(f"df shape: {args.df.shape}")
    print(args.df.columns)
    args.train_folds = args.df[args.df['split'] == "training"].reset_index(drop=True)
    args.valid_folds = args.df[args.df['split'] == "test"].reset_index(drop=True)
    train_loader, val_loader = get_dataloader_Vindr(args)
    print(f'train_loader: {len(train_loader)}, valid_loader: {len(val_loader)}')

    print(args.clip_chk_pt_path)

    ckpt = torch.load(args.clip_chk_pt_path, map_location="cpu")

    # Initialize model, loss, and optimizer
    attr_embs = torch.load(args.attr_embs_path)
    concatenated_embedding = np.concatenate((attr_embs['mass'], attr_embs['suspicious_calcification']), axis=0)
    concatenated_embedding = torch.from_numpy(concatenated_embedding).view(2, -1).to(device)
    print(concatenated_embedding.size())

    model = Mapper_w_attn(
        ckpt,
        image_embedding_size=2048, text_embedding_size=512, text_embeddings=concatenated_embedding,
        num_classes=2, num_heads=8
    ).to("cuda")
    model.train()

    weights = torch.tensor([15.573306370070778, 37.296728971962615]).to(device)
    loss_fn = torch.nn.BCEWithLogitsLoss(pos_weight=weights)

    # Optimizer
    optimizer = Adam(model.parameters(), lr=args.lr)

    best_auc = 0.0

    for epoch in range(args.epochs):
        train_one_epoch(epoch, model, train_loader, device, optimizer, loss_fn, args.epochs)
        val_auc = validate(epoch, model, val_loader, device, args.epochs)

        # Save model if validation AUROC improved
        if val_auc > best_auc:
            best_auc = val_auc
            torch.save(model.state_dict(), f"{args.chk_pt_path}/mapper_w_attention.pth")
            print("Saved Best Model")

    print("Training completed.")


def train_one_epoch(epoch, model, train_loader, device, optimizer, criterion, epochs):
    model.train()
    running_loss = 0.0
    progress_iter = tqdm(enumerate(train_loader), desc=f"[{epoch + 1:03d}/{epochs:03d} epoch train]",
                         total=len(train_loader))
    for images, sample in progress_iter:
        labels = sample["labels"].to(torch.float32).to(device)

        optimizer.zero_grad()
        outputs = model(sample)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    avg_loss = running_loss / len(train_loader)
    print(f"Epoch [{epoch + 1}], Loss: {avg_loss:.4f}")


def validate(epoch, model, val_loader, device, epochs):
    model.eval()
    all_labels = []
    all_preds = []
    with torch.no_grad():
        progress_iter = tqdm(enumerate(val_loader), desc=f"[{epoch + 1:03d}/{epochs:03d} epoch valid]",
                             total=len(val_loader))
        for images, sample in progress_iter:
            labels = sample["labels"].to(torch.float32).to(device)
            outputs = model(sample)
            preds = torch.sigmoid(outputs).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())

    auc_score = roc_auc_score(all_labels, all_preds, multi_class='ovo')
    print(f"Epoch [{epoch + 1}], Validation AUROC: {auc_score:.4f}")
    return auc_score
