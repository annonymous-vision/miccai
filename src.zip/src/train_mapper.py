import argparse
import os
import pickle

import torch
from omegaconf import DictConfig
import hydra
from hydra.utils import instantiate
from torch.utils.data import DataLoader

from breast_clip_interpretability.train_region_mapper import train_region_mapper
from utils import seed_all, get_Paths


def config():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tensorboard-path', metavar='DIR',
                        default='/Multimodal-mistakes-debug/log',
                        help='path to tensorboard logs')
    parser.add_argument('--checkpoints', metavar='DIR',
                        default='/Multimodal-mistakes-debug/checkpoints',
                        help='path to checkpoints')
    parser.add_argument('--output_path', metavar='DIR',
                        default='/Multimodal-mistakes-debug/out',
                        help='path to output logs')
    parser.add_argument(
        "--data-dir",
        default="/RSNA_Breast_Imaging/Dataset",
        type=str, help="Path to data file"
    )
    parser.add_argument(
        "--img-dir",
        default="External/Vindr/vindr-mammo-a-large-scale-benchmark-dataset-for-computer-aided-detection-and-diagnosis-in-full-field-digital-mammography-1.0.0/images_png",
        type=str, help="Path to image file"
    )
    parser.add_argument(
        "--csv-file",
        default="External/Vindr/vindr-mammo-a-large-scale-benchmark-dataset-for-computer-aided-detection-and-diagnosis-in-full-field-digital-mammography-1.0.0/vindr_detection_v1_folds.csv",
        type=str,
        help="data csv file")
    parser.add_argument(
        "--clip_chk_pt_path",
        default="/Breast-CLIP/src/codebase/outputs/in_house_clip/b5_detector_period_n/checkpoints/fold_0/model-best-epoch-7.tar",
        type=str, help="Path to breast-clip"
    )
    parser.add_argument(
        "--attr_embs_path",
        default="/Multimodal-mistakes-debug/out/ViNDr/Interpretability/Sent_Emb/attr_embs.pth",
        type=str, help="Path to breast-clip"
    )
    parser.add_argument("--img_emb", default=1392, type=int)
    parser.add_argument("--lang_emb", default=512, type=int)
    parser.add_argument("--detector-threshold", default=0.1, type=float)
    parser.add_argument("--dataset", default="ViNDr", type=str)
    parser.add_argument("--data_frac", default=1.0, type=float)
    parser.add_argument("--label", default="cancer", type=str)
    parser.add_argument("--VER", default="084", type=str)
    parser.add_argument("--arch", default="b5_clip_mapper", type=str)
    parser.add_argument("--epochs-warmup", default=0, type=float)
    parser.add_argument("--num_cycles", default=0.5, type=float)
    parser.add_argument("--alpha", default=10, type=float)
    parser.add_argument("--sigma", default=15, type=float)
    parser.add_argument("--p", default=1.0, type=float)
    parser.add_argument("--mean", default=0.3089279, type=float)
    parser.add_argument("--std", default=0.25053555408335154, type=float)
    parser.add_argument("--focal-alpha", default=0.6, type=float)
    parser.add_argument("--focal-gamma", default=2.0, type=float)
    parser.add_argument("--num-classes", default=1, type=int)
    parser.add_argument("--n_folds", default=4, type=int)
    parser.add_argument("--start-fold", default=0, type=int)
    parser.add_argument("--seed", default=10, type=int)
    parser.add_argument("--batch-size", default=8, type=int)
    parser.add_argument("--num-workers", default=4, type=int)
    parser.add_argument("--epochs", default=20, type=int)
    parser.add_argument("--lr", default=0.0001, type=float)
    parser.add_argument("--weight-decay", default=1e-4, type=float)
    parser.add_argument("--warmup-epochs", default=1, type=float)
    parser.add_argument("--img-size", nargs='+', default=[1520, 912])
    parser.add_argument("--device", default="cuda", type=str)
    parser.add_argument("--apex", default="y", type=str)
    parser.add_argument("--print-freq", default=5000, type=int)
    parser.add_argument("--log-freq", default=1000, type=int)
    parser.add_argument("--running-interactive", default='n', type=str)
    parser.add_argument("--inference-mode", default='n', type=str)
    parser.add_argument('--model-type', default="Classifier", type=str)
    parser.add_argument("--weighted-BCE", default='n', type=str)
    parser.add_argument("--balanced-dataloader", default='n', type=str)

    return parser.parse_args()


def main(args):
    seed_all(args.seed)
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    args.root = f"lr_{args.lr}_epochs_{args.epochs}"
    args.apex = True if args.apex == "y" else False
    args.running_interactive = True if args.running_interactive == "y" else False

    chk_pt_path, output_path, tb_logs_path = get_Paths(args)
    args.chk_pt_path = chk_pt_path
    args.output_path = output_path
    args.tb_logs_path = tb_logs_path

    os.makedirs(chk_pt_path, exist_ok=True)
    os.makedirs(output_path, exist_ok=True)
    os.makedirs(tb_logs_path, exist_ok=True)
    print("====================> Paths <====================")
    print(f"checkpoint_path: {chk_pt_path}")
    print(f"output_path: {output_path}")
    print(f"tb_logs_path: {tb_logs_path}")
    print('device:', device)
    print('torch version:', torch.__version__)
    print("====================> Paths <====================")

    pickle.dump(args, open(os.path.join(output_path, f"seed_{args.seed}_train_configs.pkl"), "wb"))
    train_region_mapper(args, device)


if __name__ == "__main__":
    args = config()
    main(args)
